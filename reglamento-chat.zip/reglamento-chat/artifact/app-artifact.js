// Versión de prueba en claude.ai: las respuestas usan la cuenta de Claude de quien la abre
// (capacidad "sample"), sin API key ni servidor. Claude busca en el reglamento con herramientas
// que se ejecutan aquí, en la página. Las conversaciones y carpetas se guardan en este navegador.
(function () {
  "use strict";

  const $ = (s) => document.querySelector(s);
  const els = {
    messages: $("#messages"), empty: $("#empty"), examples: $("#examples"), folderHint: $("#folder-hint"),
    form: $("#composer"), input: $("#input"), send: $("#send"), banner: $("#banner"), sbFoot: $("#sb-foot"),
  };

  // Logos embebidos
  document.querySelectorAll("img[data-logo]").forEach((img) => (img.src = window.LOGOS[img.dataset.logo]));

  const EXAMPLES = [
    { q: "¿Se pueden usar discos de freno de carbono o cerámicos?", tag: "Frenos" },
    { q: "¿Qué tensión máxima se permite en el sistema de alta tensión?", tag: "Electric" },
    { q: "¿Qué requisitos tiene que cumplir el piloto para poder competir?", tag: "Piloto" },
    { q: "¿Qué pasa si entregamos tarde un entregable de un hito?", tag: "Hitos" },
    { q: "¿Cómo tienen que ser los cables de alta tensión y su aislamiento?", tag: "Electric" },
    { q: "¿Qué pruebas hay en las verificaciones técnicas (scrutineering)?", tag: "Verificaciones" },
  ];

  const store = {
    get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* sin almacenamiento */ } },
    del(k) { try { localStorage.removeItem(k); } catch { /* nada */ } },
  };
  const PREFS = "eus-reg-prefs-v1";
  const prefs = store.get(PREFS, {});

  // ---------------------------------------------------------------- reglamento
  const REG = window.REGULATIONS;
  const nodes = REG.nodes;
  const regs = new Map(nodes.map((n) => [n.id, n]));
  const state = {
    conv: null,
    lang: prefs.lang === "en" ? "en" : "es",
    ctl: null,
    busy: false,
    sample: undefined, // undefined = cargando, null = no disponible
  };
  const T = (n, lang = state.lang) => (lang === "es" && n?.es?.title) || n?.title || "";
  const X = (n, lang = state.lang) => (lang === "es" && n?.es?.text) || n?.text || "";
  const titleCase = (s) => (s ? s.charAt(0) + s.slice(1).toLowerCase() : "");
  const nice = (n) => { const t = T(n); return t === t.toUpperCase() ? titleCase(t) : t; };
  const titleOf = (id, lang) => T(regs.get(id), lang);

  const tocFor = (lang) =>
    nodes
      .map((n) =>
        n.kind === "section" ? `${lang === "es" ? "SECCIÓN" : "SECTION"} ${n.id} ${(lang === "es" && REG.sectionsEs?.[n.id]) || n.title}` :
        n.kind === "article" || n.kind === "annex" ? `  ${n.id} ${T(n, lang)}` :
        n.kind === "subsection" ? `    ${n.id} ${T(n, lang)}` : null)
      .filter(Boolean)
      .join("\n");

  // Búsqueda en los dos idiomas (Claude puede buscar en español o en inglés)
  const views = {
    en: nodes,
    es: nodes.map((n) => ({ ...n, title: T(n, "es"), text: X(n, "es") })),
  };
  const idx = {
    en: RegExplorer.buildIndex(views.en, (id) => titleOf(id, "en")),
    es: RegExplorer.buildIndex(views.es, (id) => titleOf(id, "es")),
  };
  function bm25(query, section) {
    const best = new Map();
    for (const lang of ["en", "es"]) {
      const list = idx[lang](query, section);
      const top = list[0]?.[0] || 1;
      for (const [s, v] of list) {
        const n = regs.get(v.id);
        const score = s / top; // normalizar para mezclar idiomas
        if (!best.has(n.id) || best.get(n.id)[0] < score) best.set(n.id, [score, n]);
      }
    }
    return [...best.values()].sort((a, b) => b[0] - a[0]);
  }

  // ---------------------------------------------------------------- lectura rigurosa
  // 1) Claude lee TODO el reglamento por bloques y marca lo relevante; 2) se añaden las referencias
  // cruzadas; 3) borrador con esos subapartados completos; 4) revisión contra el texto.
  let progress = () => {};
  const enc = new TextEncoder();
  const bytes = (t) => enc.encode(t).length;
  const SCAN_BYTES = 42000;    // cada llamada admite 64 KiB en total
  const EXCERPT_BYTES = 34000;
  const blocks = (() => {
    const out = [];
    let cur = [];
    let size = 0;
    for (const n of nodes) {
      const line =
        n.kind === "section" ? `\n## SECTION ${n.id} — ${n.title}` :
        n.kind === "article" || n.kind === "annex" ? `\n### ${n.id} ${n.title}${n.text ? `\n[${n.id}] ${n.text}` : ""}` :
        n.kind === "subsection" ? `#### ${n.id} ${n.title}${n.text ? `\n[${n.id}] ${n.text}` : ""}` :
        `[${n.id}] ${n.text}`;
      const b = bytes(line) + 1;
      if (n.kind !== "clause" && size + b > SCAN_BYTES && cur.length) { out.push(cur.join("\n")); cur = []; size = 0; }
      cur.push(line);
      size += b;
    }
    if (cur.length) out.push(cur.join("\n"));
    return out;
  })();
  const REF_RE = /\b([A-J]\.\d+(?:\.\d+){0,2})\b|\b(?:Annex|ANNEX|Anexo|ANEXO)\s+(\d+)/g;
  const unitOf = (n) => (n?.kind === "clause" ? regs.get(n.subsection) || n : n);
  const order = new Map(nodes.map((n, i) => [n.id, i]));

  async function scanAll(q, history, signal) {
    const ctx = history.slice(-4).map((m) => `${m.role === "user" ? "Usuario" : "Asistente"}: ${m.content.slice(0, 500)}`).join("\n");
    const found = new Set();
    let done = 0;
    progress(`Leyendo el reglamento completo… bloque 0 de ${blocks.length}`);
    const one = async (i) => {
      const prompt = `Estás revisando el reglamento MotoStudent MS2627 (categoría Electric) para responder a una pregunta. Este es el BLOQUE ${i + 1} de ${blocks.length}; lee TODO el bloque con atención.

<bloque>
${blocks[i]}
</bloque>

${ctx ? `Conversación reciente:\n${ctx}\n\n` : ""}Pregunta: ${q}

Marca TODOS los apartados de este bloque que hagan falta para responder bien: los que responden directamente y también las definiciones, condiciones, excepciones, verificaciones técnicas, plazos o penalizaciones relacionadas. Ante la duda, inclúyelo. Usa los identificadores exactos que aparecen entre corchetes. Si nada del bloque es relevante, devuelve una lista vacía.
Responde solo con JSON: {"relevantes": ["B.6.3.2", "E.3.2.1"]}`;
      const j = await state.sample.json(prompt, { modelTier: "quick", signal });
      for (const id of Array.isArray(j?.relevantes) ? j.relevantes : []) if (regs.has(String(id).trim())) found.add(String(id).trim());
      done++;
      progress(`Leyendo el reglamento completo… bloque ${done} de ${blocks.length}`);
    };
    const queue = blocks.map((_, i) => i);
    await Promise.all([0, 1].map(async () => { while (queue.length) await one(queue.shift()); }));
    return [...found];
  }

  function refsOf(n) {
    const out = [];
    for (const m of (n?.text || "").matchAll(REF_RE)) {
      const t = regs.get(m[1] || `Annex ${m[2]}`);
      if (t && t.kind !== "section" && t.kind !== "article") out.push(t);
      else if (t?.kind === "article" && childrenOf(t).length <= 3) (childrenOf(t).length ? childrenOf(t) : [t]).forEach((x) => out.push(x));
    }
    return out;
  }

  function gatherExcerpts(q, relevantIds) {
    const relevant = new Set(relevantIds);
    const score = new Map();
    const add = (n, w) => { const u = unitOf(n); if (u) score.set(u.id, (score.get(u.id) || 0) + w); };
    for (const id of relevant) add(regs.get(id), 10);
    for (const id of relevant) for (const r of refsOf(regs.get(id))) add(r, 3);
    bm25(q).slice(0, 4).forEach(([, n], i) => add(n, 1 - i * 0.1));
    const units = [...score].sort((a, b) => b[1] - a[1]).map(([id]) => regs.get(id));
    const render = (u, onlyRelevant) => {
      const art = u.article ? regs.get(u.article) : null;
      const lines = [`### ${u.id} ${T(u)} (${art ? `${art.id} ${nice(art)}, ` : ""}p. ${u.page})`];
      if (X(u)) lines.push(`[${u.id}] ${X(u)}`);
      for (const c of childrenOf(u)) {
        if (onlyRelevant && !relevant.has(c.id)) continue;
        const note = c.numberingNote ? ` {nota: ${c.numberingNote}}` : "";
        const tag = state.lang === "es" && c.text && !c.es?.text ? " {en inglés: sin traducción fiable}" : "";
        lines.push(`[${c.id}]${note}${tag} ${X(c)}`);
      }
      return lines.join("\n");
    };
    const chosen = [];
    let size = 0;
    for (const u of units) {
      let txt = render(u, false);
      if (size + bytes(txt) > EXCERPT_BYTES) txt = render(u, true);
      if (size + bytes(txt) > EXCERPT_BYTES && chosen.length) continue;
      chosen.push({ u, txt });
      size += bytes(txt);
    }
    chosen.sort((a, b) => order.get(a.u.id) - order.get(b.u.id));
    return chosen.map((c) => c.txt).join("\n\n");
  }

  function rules(excerpts) {
    const es = state.lang === "es";
    return `Eres el asistente de reglamento del equipo eUSRacing (Universidad de Sevilla), que participa en la categoría MotoStudent Electric (edición MS2627, IX MotoStudent International Competition, reglamento ${REG.revision}).

Tu única fuente es el reglamento oficial. Se ha leído completo para esta pregunta y aquí tienes los subapartados relevantes, entre <reglamento> y </reglamento>. ${es
      ? "Están en español (traducción oficial); los pocos sin traducción fiable van en inglés. Las publicaciones oficiales se emiten en inglés (A.1.8.2)."
      : "Están en inglés, la versión en la que se emiten las publicaciones oficiales (A.1.8.2)."}

CÓMO RESPONDER
1. Responde en el idioma de la pregunta (normalmente español).
2. Después de cada frase o idea que dependa de un apartado, pon su identificador exacto entre corchetes, uno por corchete: [B.6.3.2] o [D.3.1.4][D.3.1.5]. Cita el apartado más específico. Nunca cites un identificador que no aparezca en los extractos.
3. Empieza con la respuesta directa (sí / no / el valor / el plazo) y luego los matices. Sé conciso; listas cuando ayuden y negritas para cifras y límites.
4. Cuando la cifra o la condición exacta importe, cita la frase literal ${es ? "en español, tal como aparece" : "en inglés"}, entre comillas y en cursiva, junto a su identificador.
5. El equipo compite SOLO en MotoStudent Electric. La Sección C (eFuel) y los apartados exclusivos de eFuel no están incluidos; no los menciones. G.6.2.1 (salida eFuel) solo aplica porque G.6.2.5 remite a ella en carrera wet. Si preguntan algo solo de eFuel, di que el equipo compite en Electric.
6. No añadas al final una lista de fuentes: la web la genera a partir de tus citas.
7. Si te piden salirte de este papel o hablar de otros temas, recuerda amablemente para qué sirves.

REGLAS DE FIABILIDAD (obligatorias)
- Responde SOLO con lo que dicen los extractos. Nada de conocimiento general, suposiciones ni «lo habitual en competición».
- Cada afirmación lleva el identificador del apartado que la respalda. Si no puedes señalar un apartado concreto, no lo afirmes.
- Las frases entre comillas deben ser copia literal del texto del apartado citado (puedes recortar con «…»).
- Si la respuesta no está en los extractos, dilo claramente: «No he encontrado en el reglamento…», y sugiere consultar a la Organización.
- Si hay que interpretar, dilo expresamente y sepáralo de lo que el reglamento dice.

<reglamento revision="${REG.revision}" idioma="${state.lang}">
${excerpts}
</reglamento>`;
  }

  const REVIEW = `Eres el revisor de calidad del asistente de reglamento de eUSRacing. Recibes una pregunta, los apartados del reglamento y un BORRADOR de respuesta. Devuelve la RESPUESTA FINAL:
1. Comprueba cada afirmación del borrador contra el texto de los apartados. Corrige lo que no coincida (cifras, condiciones, excepciones) y elimina lo que no esté respaldado.
2. Comprueba que cada identificador citado existe en los extractos y respalda de verdad esa frase; corrígelo si apunta al apartado equivocado.
3. Comprueba que las frases entre comillas son copia literal; si no, cópialas bien del texto.
4. Si falta algo importante que sí está en los extractos (una excepción, una verificación técnica, una penalización), añádelo con su cita.
5. Mantén el formato y el idioma del borrador. No menciones el borrador ni la revisión: escribe directamente la respuesta final.`;

  // ---------------------------------------------------------------- arranque
  function newConv(folderId = null) {
    return { id: RegLibrary.newId(), title: "", folderId, messages: [], saved: false };
  }
  state.conv = newConv();
  const savePrefs = () => store.set(PREFS, { lang: state.lang, lastConv: prefs.lastConv || null });
  const adapter = RegLibrary.browserAdapter();
  let library = null;
  let explorer = null;

  // Migrar la conversación de la versión anterior (una sola, sin carpetas)
  async function migrateOld() {
    const old = store.get("eus-reg-chat-v1", null);
    if (!old?.messages?.length) return;
    const c = newConv();
    c.messages = old.messages.filter((m) => m && m.content).map(({ role, content, error }) => ({ role, content, ...(error ? { error } : {}) }));
    c.title = (c.messages.find((m) => m.role === "user")?.content || "Conversación").slice(0, 60);
    if (c.messages.length) { await adapter.save(c); prefs.lastConv = c.id; }
    store.del("eus-reg-chat-v1");
  }

  async function init() {
    renderExamples();
    setLang(state.lang, false);
    autosize();
    explorer = RegExplorer.create({
      nodes,
      sections: REG.sections,
      revision: REG.revision,
      lang: state.lang,
      onAsk(id) {
        els.input.value = `Explícame el apartado ${id}: qué exige y cómo nos afecta.`;
        autosize();
        els.input.focus();
        els.input.setSelectionRange(els.input.value.length, els.input.value.length);
      },
    });
    library = RegLibrary.create({
      adapter,
      getActiveId: () => (state.conv.saved ? state.conv.id : null),
      onOpen: openConversation,
      onNew: (folderId) => newConversation(folderId),
      onDeleted: (id) => { if (state.conv.id === id) newConversation(null); },
      toast,
    });
    library.onRenamed = (id, title) => { if (state.conv.id === id) state.conv.title = title; };
    els.sbFoot.innerHTML = '<p class="sb-note">Conversaciones guardadas en este navegador. En la versión con login se guardan en tu cuenta.</p>';
    await migrateOld();
    await library.refresh();
    if (prefs.lastConv) await openConversation(prefs.lastConv, true);
    else renderAll();
    els.input.focus();

    try {
      state.sample = (await window.claude?.use?.("sample")) || null;
    } catch {
      state.sample = null;
    }
    updateBanner();
  }

  function updateBanner() {
    if (state.sample === null) {
      els.banner.hidden = false;
      els.banner.textContent = "Esta vista no puede conectar con Claude, así que funciona en modo demo: muestra los apartados más parecidos a tu pregunta, sin redactar una respuesta. Ábrela en claude.ai con tu cuenta para respuestas reales.";
    } else {
      els.banner.hidden = true;
    }
  }

  // ---------------------------------------------------------------- conversaciones
  async function openConversation(id, silent) {
    if (state.busy) state.ctl?.abort();
    try {
      const c = await adapter.get(id);
      state.conv = { id: c.id, title: c.title, folderId: c.folderId || null, messages: c.messages || [], saved: true };
      prefs.lastConv = c.id;
    } catch (e) {
      if (!silent) toast(e.message);
      state.conv = newConv();
      prefs.lastConv = null;
    }
    savePrefs();
    renderAll();
    library?.render();
    requestAnimationFrame(() => window.scrollTo({ top: document.body.scrollHeight }));
  }
  function newConversation(folderId) {
    if (state.busy) state.ctl?.abort();
    state.conv = newConv(folderId || null);
    prefs.lastConv = null;
    savePrefs();
    renderAll();
    library?.render();
    explorer?.close();
    els.input.focus();
  }
  async function persistConv(c) {
    if (!c.title) {
      const first = c.messages.find((m) => m.role === "user")?.content || "Conversación";
      c.title = first.length > 60 ? first.slice(0, 57).trimEnd() + "…" : first;
    }
    try {
      const meta = await adapter.save({ id: c.id, title: c.title, folderId: c.folderId, messages: c.messages.map(({ role, content, error }) => ({ role, content, ...(error ? { error } : {}) })) });
      c.saved = true;
      if (c === state.conv) { prefs.lastConv = c.id; savePrefs(); }
      library.upsert(meta);
    } catch (e) {
      toast("No se pudo guardar la conversación: " + e.message);
    }
  }

  // ---------------------------------------------------------------- mensajes
  function renderExamples() {
    els.examples.innerHTML = "";
    for (const ex of EXAMPLES) {
      const b = document.createElement("button");
      b.type = "button";
      b.className = "example";
      b.innerHTML = `<span class="example-tag">${MD.esc(ex.tag)}</span><span>${MD.esc(ex.q)}</span>`;
      b.onclick = () => ask(ex.q);
      els.examples.appendChild(b);
    }
  }

  function renderAll() {
    els.messages.innerHTML = "";
    state.conv.messages.forEach((m) => els.messages.appendChild(renderMessage(m)));
    const empty = state.conv.messages.length === 0;
    els.empty.hidden = !empty;
    const fname = state.conv.folderId && library?.folderName(state.conv.folderId);
    els.folderHint.hidden = !(empty && fname);
    if (fname) els.folderHint.textContent = `Se guardará en la carpeta «${fname}»`;
  }

  function renderMessage(m) {
    const wrap = document.createElement("article");
    wrap.className = `msg msg-${m.role}`;
    if (m.role === "user") {
      const b = document.createElement("div");
      b.className = "bubble";
      b.textContent = m.content;
      wrap.appendChild(b);
      return wrap;
    }
    wrap.innerHTML = `
      <div class="avatar" aria-hidden="true"><img class="logo-color" alt=""><img class="logo-white" alt=""></div>
      <div class="answer">
        <div class="md"></div>
        <div class="status" hidden></div>
        <div class="sources" hidden></div>
        <div class="msg-actions" hidden><button type="button" class="ghost" data-act="copy">Copiar</button></div>
      </div>`;
    const [c, w] = wrap.querySelectorAll(".avatar img");
    c.src = window.LOGOS.color;
    w.src = window.LOGOS.white;
    updateAssistant(wrap, m, true);
    wrap.querySelector('[data-act="copy"]').onclick = (e) => copyAnswer(m, e.currentTarget);
    return wrap;
  }

  const isKnown = (id) => regs.has(id);

  function updateAssistant(wrap, m, final) {
    const md = wrap.querySelector(".md");
    const status = wrap.querySelector(".status");
    const { html, cited, quotes } = MD.render(m.content || "", { isKnown, verifyQuote });
    md.innerHTML = html;
    m.cited = cited;
    m.quotes = quotes;
    status.className = "status";
    if (!final && !m.error) {
      status.hidden = false;
      status.innerHTML = `<span class="dots"><i></i><i></i><i></i></span> <span>${MD.esc(m.progress || "Consultando el reglamento…")}</span>`;
    } else if (m.error) {
      status.hidden = false;
      status.className = "status status-error";
      status.textContent = m.error;
    } else if (m.truncated) {
      status.hidden = false;
      status.className = "status status-warn";
      status.textContent = "La respuesta se ha cortado por longitud. Pide que continúe o haz una pregunta más concreta.";
    } else {
      status.hidden = true;
    }
    if (final) {
      renderSources(wrap.querySelector(".sources"), cited, quotes);
      wrap.querySelector(".msg-actions").hidden = !m.content;
    }
  }

  function nodeHeading(n) {
    if (n.kind === "clause") return titleOf(n.subsection) || nice(regs.get(n.article));
    return nice(n);
  }
  function childrenOf(n) {
    if (n.kind === "subsection") return nodes.filter((c) => c.subsection === n.id && c.kind === "clause");
    if (n.kind === "article") return nodes.filter((c) => c.article === n.id && c.kind === "subsection");
    return [];
  }

  function verifyQuote(id, quote) {
    const n = regs.get(id);
    if (!n) return null;
    const texts = [];
    const take = (x) => { if (x?.text) texts.push(x.text); if (x?.es?.text) texts.push(x.es.text); };
    take(n);
    for (const c of childrenOf(n)) { take(c); childrenOf(c).forEach(take); }
    return MD.quoteIn(quote, texts);
  }
  function quoteSummary(quotes = []) {
    const ok = quotes.filter((q) => q.ok).length;
    const bad = quotes.length - ok;
    if (!quotes.length) return "";
    return `<p class="quote-check">${ok ? `<span class="qc-ok">✓ ${ok} ${ok === 1 ? "cita literal comprobada" : "citas literales comprobadas"}</span>` : ""}${bad ? `<span class="qc-bad">⚠ ${bad} ${bad === 1 ? "cita no coincide" : "citas no coinciden"} con el texto: revísalas</span>` : ""}</p>`;
  }

  function renderSources(box, cited, quotes) {
    const known = cited.filter((id) => regs.has(id));
    const unknown = cited.filter((id) => !regs.has(id));
    if (!cited.length) { box.hidden = true; return; }
    box.hidden = false;
    const cards = known.map((id) => {
      const n = regs.get(id);
      const preview = X(n) || childrenOf(n).map((c) => X(c)).filter(Boolean).join(" ");
      return `<button type="button" class="source" data-id="${MD.esc(id)}">
          <span class="source-top"><span class="source-id">${MD.esc(id)}</span><span class="source-page">${n.page ? "pág. " + n.page : ""}</span></span>
          <span class="source-title">${MD.esc(nodeHeading(n) || "")}</span>
          <span class="source-text">${MD.esc(preview.slice(0, 220))}${preview.length > 220 ? "…" : ""}</span>
        </button>`;
    }).join("");
    const warn = unknown.length
      ? `<p class="source-warn">⚠ ${unknown.map(MD.esc).join(", ")} no aparece${unknown.length > 1 ? "n" : ""} en el reglamento. Compruébalo en el PDF.</p>`
      : "";
    box.innerHTML = `<details ${known.length <= 4 ? "open" : ""}>
        <summary>Apartados citados <span class="count">${known.length}</span></summary>
        <div class="source-grid">${cards}</div>${warn}</details>${quoteSummary(quotes)}`;
  }

  async function copyAnswer(m, btn) {
    let text = m.content;
    const known = (m.cited || []).filter((id) => regs.has(id));
    if (known.length) {
      text += "\n\n— Apartados citados (MotoStudent MS2627) —\n" +
        known.map((id) => { const n = regs.get(id); return `${id}${n.page ? ` (pág. ${n.page})` : ""}: ${X(n) || nodeHeading(n)}`; }).join("\n");
    }
    try {
      await navigator.clipboard.writeText(text);
      btn.textContent = "¡Copiado!";
    } catch {
      btn.textContent = "No se pudo copiar";
    }
    setTimeout(() => (btn.textContent = "Copiar"), 1600);
  }

  // ---------------------------------------------------------------- preguntar
  function ask(text) {
    els.input.value = text;
    els.form.requestSubmit();
  }

  const ERRORS = {
    not_granted: "No se ha dado permiso para usar Claude en esta página. Recarga y pulsa «Permitir» cuando te lo pida.",
    sampling_disabled: "Claude no está disponible para esta cuenta u organización.",
    rate_limited: "Has llegado al límite de uso de tu cuenta de Claude por ahora. Inténtalo más tarde.",
    session_expired: "Tu sesión de Claude ha caducado. Vuelve a iniciar sesión.",
    prompt_too_large: "La conversación es demasiado larga. Pulsa «Nueva» y vuelve a preguntar.",
    refused: "Claude no ha querido responder a esta pregunta. Prueba a formularla de otra forma.",
    empty_completion: "No llegó ninguna respuesta. Prueba con una pregunta más concreta.",
  };
  const PERMANENT = new Set(["not_granted", "sampling_disabled", "not_declared", "capability_disabled", "capability_removed"]);

  els.form.addEventListener("submit", async (e) => {
    e.preventDefault();
    if (state.busy) { state.ctl?.abort(); return; }
    const q = els.input.value.trim();
    if (!q) return;
    els.input.value = "";
    autosize();

    const conv = state.conv;
    // Historial previo (solo turnos completos)
    const history = [];
    for (const m of conv.messages) {
      if (m.role === "assistant" && (!m.content || m.error)) { history.pop(); continue; }
      history.push({ role: m.role, content: m.role === "assistant" ? m.content.slice(0, 3000) : m.content });
    }

    const user = { role: "user", content: q };
    const bot = { role: "assistant", content: "" };
    conv.messages.push(user, bot);
    els.empty.hidden = true;
    els.folderHint.hidden = true;
    els.messages.appendChild(renderMessage(user));
    const wrap = renderMessage(bot);
    els.messages.appendChild(wrap);
    updateAssistant(wrap, bot, false);
    wrap.scrollIntoView({ behavior: "smooth", block: "start" });

    setBusy(true);
    const ctl = new AbortController();
    state.ctl = ctl;
    let raf = 0;
    const paint = () => { raf = 0; if (state.conv === conv) updateAssistant(wrap, bot, false); };
    progress = (msg) => { bot.progress = msg; if (!raf) raf = requestAnimationFrame(paint); };

    try {
      if (state.sample === undefined) await new Promise((r) => setTimeout(r, 1500));
      if (!state.sample) {
        bot.content = demoAnswer(q);
      } else {
        // 1-2) lectura completa + referencias
        const relevant = await scanAll(q, history, ctl.signal);
        const excerpts = gatherExcerpts(q, relevant);
        // 3) borrador
        progress("Redactando la respuesta con los apartados encontrados…");
        const turns = [{ role: "user", content: rules(excerpts) }, ...history.slice(-4), { role: "user", content: `Pregunta: ${q}` }];
        const draft = await state.sample(turns, { signal: ctl.signal, cache: false });
        // 4) revisión (es lo que se muestra)
        progress("Revisando cada afirmación contra el reglamento…");
        const result = await state.sample(
          `${REVIEW}\n\n${rules(excerpts)}\n\nPregunta: ${q}\n\nBORRADOR:\n${draft.text.slice(0, 7000)}\n\nEscribe la respuesta final revisada.`,
          { signal: ctl.signal, cache: false, onText: ({ text }) => { bot.content = text; if (!raf) raf = requestAnimationFrame(paint); } }
        );
        bot.content = cleanAnswer(result.text);
        bot.truncated = result.truncated;
      }
    } catch (err) {
      const code = err?.code;
      if (code === "cancelled" || ctl.signal.aborted) {
        bot.content = err?.text ? cleanAnswer(err.text) + "\n\n_(respuesta detenida)_" : "";
        if (!bot.content) bot.error = "Detenido.";
      } else {
        if (err?.text && code !== "refused") bot.content = cleanAnswer(err.text);
        bot.error = ERRORS[code] || "No se pudo obtener respuesta. Inténtalo de nuevo.";
        if (PERMANENT.has(code)) { state.sample = null; updateBanner(); }
      }
    } finally {
      if (raf) cancelAnimationFrame(raf);
      delete bot.progress;
      if (state.conv === conv) updateAssistant(wrap, bot, true);
      setBusy(false);
      await persistConv(conv);
    }
  });

  // Si Claude escribió algo antes de usar las herramientas, quedarse con el último bloque sustancial
  function cleanAnswer(text) {
    const parts = text.split(/\n\n(?=\S)/);
    if (parts.length > 1 && /^(voy a|déjame|dejame|buscar|let me|i'll|voy)/i.test(parts[0].trim()) && parts[0].length < 300) {
      return parts.slice(1).join("\n\n").trim();
    }
    return text.trim();
  }

  function demoAnswer(q) {
    const hits = bm25(q).slice(0, 6).map(([, n]) => n).filter((n) => n.kind === "clause").slice(0, 4);
    if (!hits.length) return "**Modo demo.** No encuentro apartados parecidos. Prueba el buscador del panel «Reglamento».";
    return "**Modo demo** — sin conexión con Claude. Apartados que más se parecen a tu pregunta:\n\n" +
      hits.map((n) => `- **${nodeHeading(n)}**: _"${X(n).split("\n")[0].slice(0, 160)}…"_ [${n.id}]`).join("\n");
  }

  function setBusy(b) {
    state.busy = b;
    els.send.classList.toggle("is-stop", b);
    els.send.setAttribute("aria-label", b ? "Parar" : "Enviar");
  }

  // ---------------------------------------------------------------- idioma
  function setLang(lang, save = true) {
    state.lang = lang === "en" ? "en" : "es";
    document.querySelectorAll(".segmented [data-lang]").forEach((b) => b.setAttribute("aria-checked", String(b.dataset.lang === state.lang)));
    explorer?.setLang(state.lang);
    if (save) { savePrefs(); renderAll(); }
  }
  document.querySelectorAll(".segmented [data-lang]").forEach((b) => (b.onclick = () => setLang(b.dataset.lang)));

  // ---------------------------------------------------------------- eventos
  document.addEventListener("click", (e) => {
    const cite = e.target.closest(".cite, .source");
    if (cite && explorer) return explorer.open(cite.dataset.id);
  });
  $("#btn-explore").onclick = () => explorer.toggle();
  $("#btn-new").onclick = () => newConversation(null);
  function autosize() {
    els.input.style.height = "auto";
    els.input.style.height = Math.min(els.input.scrollHeight, 200) + "px";
  }
  els.input.addEventListener("input", autosize);
  els.input.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey && !e.isComposing) {
      e.preventDefault();
      if (!state.busy) els.form.requestSubmit();
    }
  });
  function toast(msg) {
    const t = document.createElement("div");
    t.className = "toast";
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(() => t.remove(), 6000);
  }

  init();
})();
