#!/usr/bin/env python3
"""Genera artifact/reglamento-chat.html: versión autocontenida para publicar en claude.ai."""
import base64
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
pub = ROOT / "public"

css = (pub / "styles.css").read_text(encoding="utf-8")

# 1) Tema oscuro compatible con el selector de tema del visor (data-theme)
m = re.search(r"@media \(prefers-color-scheme: dark\) \{\n  :root \{\n(.*?)\n  \}\n\}\n", css, re.S)
dark = m.group(1)
css = css.replace(m.group(0),
    "@media (prefers-color-scheme: dark) {\n  :root:not([data-theme=\"light\"]) {\n" + dark + "\n  }\n}\n"
    ":root[data-theme=\"dark\"] {\n" + dark + "\n}\n")
logo_old = re.search(r"@media \(prefers-color-scheme: dark\) \{\n  \.logo-color.*?\n\}\n", css, re.S).group(0)
css = css.replace(logo_old,
    "@media (prefers-color-scheme: dark) {\n"
    "  :root:not([data-theme=\"light\"]) .logo-color { display: none !important; }\n"
    "  :root:not([data-theme=\"light\"]) .logo-white { display: inline-block !important; }\n}\n"
    ":root[data-theme=\"dark\"] .logo-color { display: none !important; }\n"
    ":root[data-theme=\"dark\"] .logo-white { display: inline-block !important; }\n")
# 2) Cabecera y panel respetando la zona segura del móvil
css = css.replace("position: sticky; top: 0; z-index: 20;", "position: sticky; top: env(safe-area-inset-top, 0px); z-index: 20;")
css += """
.banner { max-width: 780px; margin: 0 auto 18px; padding: 10px 14px; border-radius: 10px;
  background: var(--warn-bg); color: var(--warn); font-size: 14px; }
"""

body = (pub / "index.html").read_text(encoding="utf-8")
body = body[body.index("<body>") + 6: body.index('<dialog id="code-dialog"')]
# logos: se rellenan desde JS para no repetir los data URI
body = re.sub(r'<img src="logo\.png"([^>]*)class="([^"]*logo-color[^"]*)"', r'<img data-logo="color"\1class="\2"', body)
body = re.sub(r'<img src="logo-blanco\.png"([^>]*)class="([^"]*logo-white[^"]*)"', r'<img data-logo="white"\1class="\2"', body)
body = body.replace('<main class="chat" id="chat">', '<main class="chat" id="chat">\n      <div class="banner" id="banner" hidden></div>')
body = body.replace("Respuestas generadas por IA a partir del reglamento <span id=\"rev-inline\">MS2627 V1.0</span>.",
                    "Versión de prueba: las respuestas usan tu cuenta de Claude. Reglamento MS2627 Rev. 01 – 04/2026 (V1.0).")
body = body.replace('<small id="revision">MS2627 · MotoStudent Electric</small>', '<small id="revision">MS2627 Electric · Rev. 01 – 04/2026 · prueba</small>')
assert "data-logo" in body and 'src="logo' not in body, "logos sin sustituir"

def data_uri(p):
    return "data:image/png;base64," + base64.b64encode(p.read_bytes()).decode()

logos = {"color": data_uri(pub / "logo.png"), "white": data_uri(pub / "logo-blanco.png")}

doc = json.loads((ROOT / "data" / "regulations.json").read_text(encoding="utf-8"))
keep = ["id", "kind", "section", "article", "subsection", "title", "page", "text", "numberingNote"]
EXCLUDE = {"C"}  # el equipo compite en Electric: fuera la Sección C (eFuel)
EFUEL_ONLY_IDS = {"E.4", "B.10.3.3", "G.3.4.4", "G.6.2.6"}  # igual que lib/regulations.js
def keep_node(n):
    return n["section"] not in EXCLUDE and not ({n["id"], n.get("article"), n.get("subsection")} & EFUEL_ONLY_IDS)
nodes = [{k: n[k] for k in keep if n.get(k) not in (None, "")} for n in doc["nodes"] if keep_node(n)]
sections = {k: v for k, v in doc["sections"].items() if k not in EXCLUDE}
# Traducción al español alineada por apartado (sin los dudosos, que se muestran en inglés)
es_doc = json.loads((ROOT / "data" / "regulations.es.json").read_text(encoding="utf-8"))
for n in nodes:
    e = es_doc["nodes"].get(n["id"])
    if not e:
        continue
    out = {}
    if e.get("title"):
        out["title"] = e["title"]
    if e.get("text") and not e.get("doubtful"):
        out["text"] = e["text"]
    if out:
        n["es"] = out
sections_es = {k: v for k, v in es_doc.get("sections", {}).items() if k in sections}
reg = {"revision": doc["revision"], "sections": sections, "sectionsEs": sections_es, "nodes": nodes}
reg_js = json.dumps(reg, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/")

md_js = (pub / "markdown.js").read_text(encoding="utf-8")
x_js = (pub / "explorer.js").read_text(encoding="utf-8")
lib_js = (pub / "library.js").read_text(encoding="utf-8")
app_js = (ROOT / "artifact" / "app-artifact.js").read_text(encoding="utf-8")

html = f"""<title>Reglamento MotoStudent eUSRacing</title>
<meta name="description" content="Pregunta cualquier duda sobre el reglamento MotoStudent MS2627 y obtén la respuesta con los apartados citados.">
<style>
{css}
</style>
{body}
<script>window.LOGOS = {json.dumps(logos)};</script>
<script>window.REGULATIONS = {reg_js};</script>
<script>
{md_js}
</script>
<script>
{x_js}
</script>
<script>
{lib_js}
</script>
<script>
{app_js}
</script>
"""
out = ROOT / "artifact" / "reglamento-chat.html"
out.write_text(html, encoding="utf-8")
print(out, f"{len(html.encode()) / 1024:.0f} KB")
