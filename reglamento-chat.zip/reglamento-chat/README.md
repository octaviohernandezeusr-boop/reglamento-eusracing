# Chat del reglamento MotoStudent — eUSRacing

Web con un chat de IA al que se le pregunta cualquier duda sobre el reglamento **MS2627 (IX MotoStudent International Competition, Rev. 01 – 04/2026, V1.0)**. Responde en español y cita los apartados exactos en los que se basa (`B.6.3.2`, `D.3.1.4`, `Annex 5`…). Al pulsar una cita se abre ese apartado dentro de su artículo, en **español o inglés** según elijas. Cada persona entra con **Google o Apple** y tiene sus conversaciones guardadas y organizadas en **carpetas**.

## Cómo funciona

1. `scripts/parse_regulations.py` convierte el texto del reglamento en inglés en `data/regulations.json`: 1.780 apartados con su número, sección, artículo, subapartado, página y texto.
   `scripts/align_spanish.py` saca la **traducción oficial al español** del PDF bilingüe y la asigna a cada apartado numerado (`data/regulations.es.json`); ver «Versión en español».
2. La IA por defecto es **Mistral (gratis)** y trabaja en **modo riguroso** (`RIGOR=max`), pensado para que no responda «por intuición». En cada pregunta:
   1. **Lee el reglamento completo.** Lo recorre en bloques que caben en los límites gratuitos (6 bloques con Mistral) y en cada uno marca los apartados necesarios. No solo los que responden directamente: también definiciones, excepciones, verificaciones técnicas, plazos y penalizaciones.
   2. **Sigue las referencias cruzadas.** Si un apartado marcado remite a otro («as defined in Article D.7.3»), el servidor añade ese otro automáticamente.
   3. **Redacta un borrador** con esos subapartados completos delante, con la regla de no afirmar nada que no pueda citar.
   4. **Revisa el borrador.** Una segunda pasada compara cada afirmación con el texto: corrige cifras y condiciones, quita lo que no esté respaldado, arregla citas mal puestas y añade excepciones olvidadas. Esa versión revisada es la que se ve.

   Tarda unos 20–60 segundos (la web enseña en qué paso está) y gasta unos 100.000–150.000 tokens por pregunta, que en el plan gratuito de Mistral no cuestan dinero. `RIGOR=alto` sustituye la lectura completa por una elección a partir del índice (más rápido, algo menos exhaustivo) y `RIGOR=rapido` además quita la revisión. Con Claude (opción de pago, `LLM_PROVIDER=anthropic`) se le pasa el reglamento entero de una vez, con *prompt caching*.
3. Se le pide a la IA que cite cada afirmación con el identificador entre corchetes. La web hace además **dos comprobaciones automáticas**, sin IA:
   - Que cada apartado citado **exista**. Si la IA se inventa uno, aparece tachado en amarillo con un aviso.
   - Que cada **frase entre comillas** esté **literalmente** en el apartado citado, en español o en inglés. Si coincide, la cita lleva ✓; si no, se marca con ! en amarillo. Debajo de la respuesta se resume cuántas citas se han comprobado.
4. Como el equipo compite en **MotoStudent Electric**, se excluye lo que es solo de eFuel: la Sección C entera y los apartados exclusivos de eFuel de otras secciones (E.4, B.10.3.3, G.3.4.4 y G.6.2.6). No se le pasan a la IA ni aparecen en la web. Se mantiene G.6.2.1 (salida de eFuel), porque G.6.2.5 dice que Electric la usa si la carrera se declara *wet*. Se controla con `EXCLUDE_SECTIONS` en `.env` (por defecto `C`; vacío = reglamento completo); la lista de apartados está en `lib/regulations.js`.

Explorador del reglamento (botón **Reglamento**):

- Se lee por **artículos completos**, con barra de saltos a cada subapartado y paso al artículo anterior o siguiente.
- **Atrás / Adelante** como en un navegador (también con Alt + ← / →), que recuerdan dónde estabas leyendo, y botón de inicio.
- **Índice en árbol** que marca el subapartado que estás leyendo. Se ve fijo en modo ampliado y con el botón ☰ en el modo estrecho y en el móvil.
- **Búsqueda** agrupada por artículo, con los términos resaltados (tecla `/` para buscar). Escribiendo un número, por ejemplo `D.3.2`, va directo a ese apartado.
- En cada apartado: **Preguntar**, que prepara la pregunta en el chat, y **Copiar**.
- **Visto recientemente**; al volver a abrir el panel, sigue donde lo dejaste.

Conversaciones (barra lateral, botón ▯ arriba a la izquierda):

- Se guardan solas al recibir cada respuesta; el título es la primera pregunta (se puede cambiar).
- **Carpetas**: créalas con **+**, mueve conversaciones arrastrándolas o con **⋯ › Mover a**, y usa **⋯ › Nueva conversación aquí** en una carpeta. Al borrar una carpeta, sus conversaciones no se borran: pasan a «Conversaciones».
- Buscador de conversaciones por título.
- Con login, cada persona ve solo las suyas y le aparecen en cualquier dispositivo. Sin login (uso local) se guardan en el servidor; con `ACCESS_CODE`, en el navegador de cada persona.

Idioma (**ES / EN** en la cabecera): cambia el texto del explorador, de las citas y el que recibe la IA, que entonces cita las frases literales en ese idioma. La búsqueda del explorador funciona en el idioma elegido.

Además: botón para copiar la respuesta con los apartados citados, modo oscuro y diseño adaptado al móvil.

## Arrancarla en local

Requisitos: **Node.js 20 o posterior** (`node -v`).

```bash
cd reglamento-chat
npm install
cp .env.example .env      # y pon tu MISTRAL_API_KEY en .env
npm start
```

Abre **http://localhost:3000**.

- Sin clave arranca en **modo demo**: respuestas simuladas con citas reales, útil para probar la interfaz.
- **Clave gratuita de Mistral:** entra en https://console.mistral.ai, elige el plan **Experiment** (gratis, sin tarjeta, pide verificar un móvil por SMS) y crea una clave en **API Keys**.
- Para que otros ordenadores de la misma red la usen: `HOST=0.0.0.0` en `.env` y entra desde `http://IP-de-tu-ordenador:3000`.

### Qué IA usar

| Opción | Coste | Límites del plan gratuito | Para tener en cuenta |
|---|---|---|---|
| **Mistral** (por defecto, `mistral-medium-latest`) | Gratis | Pocas peticiones por segundo y un volumen mensual alto; los límites exactos se ven en su consola. Si se alcanzan, la web espera y reintenta sola | Empresa europea. En el plan gratuito puede usar las preguntas para entrenar sus modelos, y Mistral lo presenta como plan para probar y experimentar |
| **Cerebras** (`gpt-oss-120b`) | Gratis | ~5 peticiones/min, 30.000 tokens/min, 1 M tokens/día | Con el modo riguroso da para unas 6–7 preguntas al día (con `RIGOR=alto`, bastantes más). Muy rápido; el catálogo de modelos gratuitos cambia a menudo |
| **Ollama** (en vuestro ordenador) | Gratis, sin límites | Los de vuestro ordenador | Privado. Necesita un ordenador potente encendido (p. ej. un Mac con chip M y 16–32 GB de RAM con `qwen3:14b`); es más lento y algo menos preciso |
| **Claude** (`LLM_PROVIDER=anthropic`) | De pago: ~0,25 $ la primera pregunta y ~0,03–0,05 $ las siguientes mientras dura la caché | — | La más precisa: lee el reglamento entero en cada pregunta |

**Gemini (Google) no sirve gratis en este caso:** sus condiciones solo permiten usar el plan de pago cuando la aplicación la usan personas del Espacio Económico Europeo. Groq tampoco encaja bien: su plan gratuito permite muy pocos tokens por minuto.

Para cambiar de IA basta con editar `LLM_PROVIDER`, la clave y, si quieres, `LLM_MODEL` en `.env`, y reiniciar. Si se supera el límite gratuito, la web lo avisa y basta con esperar un minuto.

## Publicarla gratis (sin dominio propio)

La forma más sencilla es **Render** (plan gratuito, sin tarjeta). La web queda en una dirección del tipo `https://reglamento-eusracing.onrender.com`. El archivo `render.yaml` ya lo deja todo configurado.

**1. Sube el código a GitHub** (mejor en un repositorio **privado**)

- En https://github.com/new crea un repositorio, por ejemplo `reglamento-eusracing`, y márcalo como *Private*.
- Súbele el contenido de esta carpeta, **sin** `node_modules`, `storage` ni `.env`. Puedes arrastrar los archivos en «uploading an existing file» o usar la terminal:

  ```bash
  cd reglamento-chat
  git init && git add . && git commit -m "Chat del reglamento"
  git branch -M main
  git remote add origin https://github.com/TU_USUARIO/reglamento-eusracing.git
  git push -u origin main
  ```

  El `.gitignore` ya excluye `.env`, `node_modules` y `storage`: **tu clave de Mistral no se sube**.

**2. Crea el servicio en Render**

- Entra en https://render.com con tu cuenta de GitHub.
- **New → Blueprint**, elige el repositorio y pulsa **Apply**.
- Render pedirá dos valores:
  - `MISTRAL_API_KEY`: tu clave de Mistral.
  - `ACCESS_CODE`: el código que usará el equipo para entrar, por ejemplo una frase larga. Sin él, cualquiera con el enlace podría gastar tu cuota gratuita.
- Espera a que termine el despliegue (unos minutos) y abre la dirección que te da Render.

**3. Compártela** con el equipo junto con el código de acceso.

**Qué implica el plan gratuito de Render:**

- **Se duerme** tras 15 minutos sin visitas. La primera visita después tarda alrededor de un minuto en despertarla; luego va normal.
  Si quieres evitarlo, un servicio como https://cron-job.org puede abrir `https://TU-WEB.onrender.com/api/config` cada 10 minutos. Las 750 horas gratuitas al mes alcanzan para tenerla siempre despierta.
- **Su disco se borra** en cada reinicio. Con `ACCESS_CODE` no importa, porque las conversaciones se guardan en el navegador de cada persona.
- **Recursos modestos** (0,1 CPU y 512 MB). Sobran, porque el trabajo pesado lo hace la IA de Mistral.
- **Actualizarla:** cada vez que subas cambios a GitHub, Render la vuelve a publicar sola.

**Más adelante: login con Google y conversaciones en la cuenta de cada uno**

1. Crea una base de datos Postgres gratuita en https://neon.com (sin tarjeta; 0,5 GB, de sobra) y copia su *connection string*.
2. En Render → tu servicio → **Environment**, añade:
   - `DATABASE_URL`: la *connection string* de Neon.
   - `GOOGLE_CLIENT_ID`: ver «Configurar el login», añadiendo `https://TU-WEB.onrender.com` como origen autorizado.
   - `ALLOWED_DOMAINS`: por ejemplo `us.es`.

   Después borra `ACCESS_CODE`.

La base de datos también funciona en local: si defines `DATABASE_URL`, el servidor la usa en lugar de la carpeta `storage/`.

## Configurar el login

El login se activa en cuanto defines `GOOGLE_CLIENT_ID` y/o `APPLE_CLIENT_ID` (más `SESSION_SECRET`). La web usa los botones oficiales de Google y Apple; el servidor comprueba la firma del token de cada proveedor y crea una sesión de 30 días.

**Limita quién entra** con `ALLOWED_DOMAINS` (p. ej. `us.es,alum.us.es`) y/o `ALLOWED_EMAILS` (lista de correos). Si los dejas vacíos, puede entrar cualquier cuenta y gastar vuestra API key.

Si alguien entra con Google y otro día con Apple usando el mismo email verificado, es la misma cuenta. Ojo: si en Apple elige «Ocultar mi correo», Apple da una dirección `@privaterelay.appleid.com`. Esa dirección no coincidirá con `ALLOWED_DOMAINS`, así que tendrás que añadirla a `ALLOWED_EMAILS` o pedirle que comparta su correo real.

### Google (gratis, funciona también en local)

1. Entra en https://console.cloud.google.com, crea un proyecto (p. ej. «eUSRacing Reglamento»).
2. **Google Auth Platform → Branding**: nombre de la app, correo de soporte y logo. En **Audience** elige *External*. Mientras esté «en pruebas», solo entran los usuarios de prueba que añadas; publícala para abrirla a todo el equipo.
3. **Clients → Create client → Web application**. En **Authorized JavaScript origins** añade:
   - `http://localhost` y `http://localhost:3000` (para probar en local)
   - `https://reglamento.eusracing.com` (la web publicada)
4. Copia el **Client ID** (acaba en `.apps.googleusercontent.com`) en `GOOGLE_CLIENT_ID`. No hace falta el *client secret*.

### Apple (requiere cuenta de Apple Developer de pago y la web publicada con HTTPS)

Apple no permite `localhost` ni `http`, así que solo funcionará en el subdominio.

1. En https://developer.apple.com/account → **Certificates, Identifiers & Profiles → Identifiers**, crea un **App ID** y marca *Sign in with Apple*.
2. Crea un **Services ID** (p. ej. `com.eusracing.reglamento`) y activa *Sign in with Apple* → **Configure**:
   - *Primary App ID*: el del paso 1.
   - *Domains and Subdomains*: `reglamento.eusracing.com`
   - *Return URLs*: `https://reglamento.eusracing.com/`
3. Pon el Services ID en `APPLE_CLIENT_ID` y la Return URL exacta en `APPLE_REDIRECT_URI`.

No hace falta la clave privada de Apple: la web usa el modo ventana emergente y el servidor solo verifica el token que devuelve Apple.

### Dónde se guardan los datos

Usuarios y conversaciones van en archivos JSON dentro de `DATA_DIR` (por defecto `./storage`): `users.json` y uno por usuario en `users/`. Haz copia de esa carpeta de vez en cuando. En Docker, móntala como volumen para no perderla al actualizar.

## Publicarla en un subdominio (p. ej. `reglamento.eusracing.com`)

Antes de exponerla en internet, **activa el login y define `ALLOWED_DOMAINS` o `ALLOWED_EMAILS`** (ver arriba), o como mínimo un `ACCESS_CODE`, para que nadie de fuera gaste vuestra API key. Ajusta también `RATE_LIMIT_PER_HOUR` (por persona).

### Opción A — VPS con Node + pm2 + nginx

```bash
npm install --omit=dev
npm install -g pm2
HOST=127.0.0.1 PORT=3000 TRUST_PROXY=1 pm2 start server.js --name reglamento
pm2 save && pm2 startup
```

Bloque de nginx (con certificado de Let's Encrypt vía `certbot --nginx`):

```nginx
server {
    server_name reglamento.eusracing.com;
    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_buffering off;          # necesario para que la respuesta salga en streaming
        proxy_read_timeout 300s;
    }
}
```

En el DNS del dominio, crea un registro `A` para `reglamento` que apunte a la IP del servidor.

### Opción B — Docker (Render, Railway, Fly.io, VPS…)

```bash
docker build -t reglamento-chat .
docker run -d -p 3000:3000 --env-file .env -e TRUST_PROXY=1 -e DATA_DIR=/data -v reglamento-datos:/data --name reglamento reglamento-chat
```

En plataformas como Render o Railway basta con conectar el repositorio, definir las variables de entorno y añadir el subdominio como *custom domain* (te darán un `CNAME` para el DNS). Añade un **disco persistente** montado en `DATA_DIR`; si no, las conversaciones se pierden en cada despliegue.

> Tiene que ser un servidor Node que se quede encendido: no sirve un hosting solo de archivos estáticos, porque la API key tiene que quedarse en el servidor.

## Actualizar el reglamento

Cuando salga una nueva revisión:

1. Extrae el texto de los dos PDF: el **inglés** (numeración oficial) en `scripts/MS2627_Regulations_EN.txt` y el **bilingüe** en `scripts/MS2627_Regulations_ES_bilingue.txt`. Por ejemplo: `pdftotext "MS2627_MotoStudent Regulations V1.1.pdf" scripts/MS2627_Regulations_EN.txt`.
2. `npm run parse` para regenerar `data/regulations.json` y `data/regulations.es.json`. Avisará de números de apartado duplicados y mostrará un resumen de la alineación del español.
3. `npm test` y reinicia el servidor.

### Versión en español

En el PDF bilingüe, cada página tiene primero el texto en inglés (con los números) y después la traducción (sin números). `align_spanish.py` separa los dos bloques de cada página y reparte las líneas en español entre los apartados en inglés de esa página, comparando longitudes y finales de frase. En V1.0 queda traducido de forma fiable el 98 % de los apartados de las secciones que se usan (1.215 de 1.240).

Los 25 apartados cuya alineación no es fiable (sobre todo tablas, formularios y apartados muy largos que ocupan varias páginas, como G.6.2.2) se muestran en inglés con un aviso, y a la IA se le pasan también en inglés, marcados. En el explorador, cada apartado traducido tiene un desplegable **Original en inglés**. Según A.1.8.2, las publicaciones oficiales se emiten en inglés, así que ante cualquier duda vale el inglés.

**Erratas detectadas en V1.0:** `E.5.4.5` aparece dos veces (la primera, dentro de E.5.3, debería ser E.5.3.5), `F.5.2.3` está repetido y `F.5.8.5` está dentro de F.5.9. Para que cada cita sea inequívoca, el repetido que está fuera de sitio aparece como `E.5.4.5 (2)` y el segundo `F.5.2.3` como `F.5.2.3 (2)`, siempre con una nota.

## Estructura

```
server.js                   servidor Express: /api/chat (streaming), /api/regulations…
lib/prompt.js               instrucciones para la IA (edítalas para cambiar el estilo de respuesta)
lib/regulations.js          carga el reglamento (EN + ES) y construye el contexto con los identificadores
lib/auth.js                 login con Google/Apple (verificación del token y sesiones)
lib/store.js                usuarios, carpetas y conversaciones (archivos JSON en DATA_DIR o Postgres con DATABASE_URL)
render.yaml                 despliegue gratuito en Render
lib/llm.js                  IA gratuita (formato OpenAI): plan con el índice, extractos y respuesta
lib/search.js               búsqueda BM25 en español e inglés
lib/mock.js                 modo demo sin clave
data/regulations.json       reglamento procesado (inglés)
data/regulations.es.json    traducción alineada por apartado
scripts/parse_regulations.py  PDF inglés (texto) → JSON
scripts/align_spanish.py    PDF bilingüe (texto) → traducción por apartado
public/                     la web (sin dependencias): app.js, explorer.js (reglamento), library.js (conversaciones)
test/                       npm test: reglamento, citas, IA gratuita y login (con servidores falsos)
```

## Aviso

Las respuestas las genera una IA y pueden tener errores. Contrasta siempre los apartados citados: según el reglamento, la única versión vinculante es la publicada en la web oficial de MotoStudent (A.1.2.3). Las dudas de interpretación se consultan a la Organización por los canales oficiales.
