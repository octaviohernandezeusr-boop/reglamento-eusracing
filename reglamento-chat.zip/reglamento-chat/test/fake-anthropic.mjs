// Servidor falso que imita la API de Anthropic (streaming) para probar el backend sin gastar.
// Uso: node test/fake-anthropic.mjs 3200   y luego ANTHROPIC_BASE_URL=http://127.0.0.1:3200
import http from "node:http";
import { writeFileSync } from "node:fs";

const port = Number(process.argv[2] || 3200);
const ANSWER = `**No.** Los discos de freno de carbono o cerámicos están prohibidos: deben ser de aleación de acero [B.6.3.2].

- Texto original: _"Brake discs must be manufactured from steel alloys. The use of carbon or ceramic brake discs is strictly prohibited."_ [B.6.3.2]
- Tampoco se permiten discos con ventilación interna [B.6.3.4].
- Los soportes del disco pueden ser de aluminio, magnesio o acero, pero no de materiales compuestos [B.6.3.3].

| Elemento | Permitido |
|---|---|
| Disco | Acero [B.6.3.2] |
| ABS | No [B.6.7.1] |

Un identificador inventado para probar el aviso: [B.99.1.1].`;

let n = 0;
http
  .createServer((req, res) => {
    let body = "";
    req.on("data", (c) => (body += c));
    req.on("end", async () => {
      const json = JSON.parse(body || "{}");
      writeFileSync(`/tmp/claude-0/fake-req-${++n}.json`, JSON.stringify(json, null, 1));
      if (process.env.FAIL_THINKING && json.thinking) {
        res.writeHead(400, { "content-type": "application/json" });
        return res.end(JSON.stringify({ type: "error", error: { type: "invalid_request_error", message: "thinking.type: adaptive is not supported for this model" } }));
      }
      res.writeHead(200, { "content-type": "text/event-stream" });
      const ev = (type, data) => res.write(`event: ${type}\ndata: ${JSON.stringify({ type, ...data })}\n\n`);
      ev("message_start", { message: { id: "msg_fake", type: "message", role: "assistant", model: json.model, content: [], stop_reason: null, usage: { input_tokens: 40, cache_creation_input_tokens: 0, cache_read_input_tokens: 98000, output_tokens: 1 } } });
      let idx = 0;
      if (json.thinking) {
        ev("content_block_start", { index: idx, content_block: { type: "thinking", thinking: "", signature: "" } });
        ev("content_block_delta", { index: idx, delta: { type: "signature_delta", signature: "sig" } });
        ev("content_block_stop", { index: idx });
        idx++;
      }
      ev("content_block_start", { index: idx, content_block: { type: "text", text: "" } });
      for (const chunk of ANSWER.match(/[\s\S]{1,20}/g)) {
        ev("content_block_delta", { index: idx, delta: { type: "text_delta", text: chunk } });
        await new Promise((r) => setTimeout(r, 15));
      }
      ev("content_block_stop", { index: idx });
      ev("message_delta", { delta: { stop_reason: "end_turn", stop_sequence: null }, usage: { output_tokens: 180 } });
      ev("message_stop", {});
      res.end();
    });
  })
  .listen(port, () => console.log("fake anthropic on", port));
