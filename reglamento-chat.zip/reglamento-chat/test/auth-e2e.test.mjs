// Prueba de extremo a extremo del login: arranca el servidor con un proveedor de identidad falso
// (claves generadas aquí), firma ID tokens como si fueran de Google/Apple y recorre el flujo.
import { test, before, after } from "node:test";
import assert from "node:assert/strict";
import http from "node:http";
import { spawn } from "node:child_process";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { generateKeyPair, exportJWK, SignJWT } from "jose";

const PORT = 3977;
const BASE = `http://127.0.0.1:${PORT}`;
let jwksServer, srv, key, dataDir;

before(async () => {
  const kp = await generateKeyPair("RS256");
  key = kp.privateKey;
  const jwk = { ...(await exportJWK(kp.publicKey)), kid: "test", alg: "RS256", use: "sig" };
  jwksServer = http.createServer((req, res) => { res.setHeader("content-type", "application/json"); res.end(JSON.stringify({ keys: [jwk] })); });
  await new Promise((r) => jwksServer.listen(3978, r));
  dataDir = mkdtempSync(join(tmpdir(), "eus-auth-"));
  srv = spawn(process.execPath, ["server.js"], {
    cwd: new URL("..", import.meta.url).pathname,
    env: {
      ...process.env, NODE_ENV: "test", PORT: String(PORT), HOST: "127.0.0.1", DATA_DIR: dataDir, ANTHROPIC_API_KEY: "", ANTHROPIC_BASE_URL: "",
      GOOGLE_CLIENT_ID: "google-client.apps.googleusercontent.com", APPLE_CLIENT_ID: "com.eusracing.reglamento",
      SESSION_SECRET: "x".repeat(40), ALLOWED_DOMAINS: "us.es,eusracing.com", ALLOWED_EMAILS: "invitado@gmail.com",
      TEST_JWKS_URL: "http://127.0.0.1:3978/jwks",
    },
    stdio: "pipe",
  });
  await new Promise((ok, ko) => {
    const t = setTimeout(() => ko(new Error("el servidor no arrancó")), 8000);
    srv.stdout.on("data", (d) => { if (String(d).includes("→ http")) { clearTimeout(t); ok(); } });
    srv.stderr.on("data", (d) => process.stderr.write(d));
  });
});
after(() => { srv?.kill(); jwksServer?.close(); rmSync(dataDir, { recursive: true, force: true }); });

// Cliente con "tarro" de cookies
function client() {
  const jar = new Map();
  return async (path, opts = {}) => {
    const res = await fetch(BASE + path, { ...opts, headers: { "content-type": "application/json", cookie: [...jar].map(([k, v]) => `${k}=${v}`).join("; "), ...(opts.headers || {}) } });
    for (const c of res.headers.getSetCookie()) {
      const [kv] = c.split(";");
      const [k, v] = kv.split("=");
      if (/Max-Age=0/.test(c)) jar.delete(k); else jar.set(k, v);
    }
    return { status: res.status, body: await res.json().catch(() => null) };
  };
}
const token = (claims, { iss = "https://accounts.google.com", aud = "google-client.apps.googleusercontent.com" } = {}) =>
  new SignJWT({ email_verified: true, ...claims }).setProtectedHeader({ alg: "RS256", kid: "test" }).setIssuer(iss).setAudience(aud).setIssuedAt().setExpirationTime("5m").sign(key);

test("sin sesión no hay acceso y la config anuncia Google y Apple", async () => {
  const c = client();
  const cfg = (await c("/api/config")).body;
  assert.equal(cfg.auth.mode, "oauth");
  assert.equal(cfg.auth.google, "google-client.apps.googleusercontent.com");
  assert.equal(cfg.auth.apple.clientId, "com.eusracing.reglamento");
  assert.equal((await c("/api/library")).status, 401);
  assert.equal((await c("/api/regulations")).status, 401);
  assert.equal((await c("/api/chat", { method: "POST", body: "{}" })).status, 401);
});

test("login con Google, conversaciones propias y cierre de sesión", async () => {
  const c = client();
  const { nonce } = (await c("/auth/nonce")).body;
  const r = await c("/auth/google", { method: "POST", body: JSON.stringify({ idToken: await token({ sub: "g-1", email: "ana@us.es", name: "Ana", nonce }) }) });
  assert.equal(r.status, 200, JSON.stringify(r.body));
  assert.equal(r.body.user.email, "ana@us.es");
  assert.equal((await c("/api/me")).body.user.name, "Ana");
  // El nonce es de un solo uso
  const replay = await c("/auth/google", { method: "POST", body: JSON.stringify({ idToken: await token({ sub: "g-1", email: "ana@us.es", nonce }) }) });
  assert.equal(replay.status, 401);
  // Biblioteca
  const f = (await c("/api/folders", { method: "POST", body: JSON.stringify({ name: "Baterías" }) })).body;
  await c("/api/conversations/conv0001", { method: "PUT", body: JSON.stringify({ title: "Tensión", folderId: f.id, messages: [{ role: "user", content: "¿Tensión máxima?" }] }) });
  const lib = (await c("/api/library")).body;
  assert.equal(lib.folders[0].name, "Baterías");
  assert.equal(lib.conversations[0].folderId, f.id);
  assert.equal((await c("/api/conversations/conv0001")).body.messages[0].content, "¿Tensión máxima?");
  // Otro usuario no ve las conversaciones de Ana
  const c2 = client();
  const n2 = (await c2("/auth/nonce")).body.nonce;
  await c2("/auth/google", { method: "POST", body: JSON.stringify({ idToken: await token({ sub: "g-2", email: "invitado@gmail.com", nonce: n2 }) }) });
  assert.equal((await c2("/api/library")).body.conversations.length, 0);
  assert.equal((await c2("/api/conversations/conv0001")).status, 404);
  // Cerrar sesión
  await c("/auth/logout", { method: "POST" });
  assert.equal((await c("/api/me")).body.user, null);
});

test("Apple: nonce en SHA-256, nombre de la primera vez y misma cuenta si coincide el email", async () => {
  const { createHash } = await import("node:crypto");
  const c = client();
  const { nonce } = (await c("/auth/nonce")).body;
  const sha = createHash("sha256").update(nonce).digest("hex");
  const idToken = await token({ sub: "001234.apple", email: "ana@us.es", nonce: sha }, { iss: "https://appleid.apple.com", aud: "com.eusracing.reglamento" });
  const r = await c("/auth/apple", { method: "POST", body: JSON.stringify({ idToken, user: { name: { firstName: "Ana", lastName: "García" } } }) });
  assert.equal(r.status, 200, JSON.stringify(r.body));
  // Mismo email verificado que la cuenta de Google → misma biblioteca
  assert.equal((await c("/api/library")).body.conversations.length, 1);
});

test("cuentas fuera de la lista de permitidos, tokens de otra app y firmas falsas se rechazan", async () => {
  const c = client();
  let n = (await c("/auth/nonce")).body.nonce;
  let r = await c("/auth/google", { method: "POST", body: JSON.stringify({ idToken: await token({ sub: "g-3", email: "intruso@gmail.com", nonce: n }) }) });
  assert.equal(r.status, 403);
  assert.match(r.body.error, /no tiene acceso/);
  n = (await c("/auth/nonce")).body.nonce;
  r = await c("/auth/google", { method: "POST", body: JSON.stringify({ idToken: await token({ sub: "g-4", email: "ana@us.es", nonce: n }, { aud: "otra-app" }) }) });
  assert.equal(r.status, 401);
  n = (await c("/auth/nonce")).body.nonce;
  const good = await token({ sub: "g-5", email: "ana@us.es", nonce: n });
  const forged = good.slice(0, -4) + (good.endsWith("AAAA") ? "BBBB" : "AAAA");
  r = await c("/auth/google", { method: "POST", body: JSON.stringify({ idToken: forged }) });
  assert.equal(r.status, 401);
  // Cookie de sesión manipulada
  const res = await fetch(BASE + "/api/me", { headers: { cookie: "eus_sess=eyJ1aWQiOiJ1X2FkbWluIn0.firma-falsa" } });
  assert.equal((await res.json()).user, null);
});
