// Motor gratuito (formato OpenAI): plan con el índice, extractos y respuesta en streaming.
import { test, before, after } from "node:test";
import assert from "node:assert/strict";
import http from "node:http";
import { loadRegulations, EFUEL_ONLY_IDS } from "../lib/regulations.js";
import { createOpenAIEngine, friendlyLLMError } from "../lib/llm.js";

const regs = loadRegulations(new URL("../data/regulations.json", import.meta.url).pathname, {
  exclude: ["C"], excludeIds: EFUEL_ONLY_IDS, esPath: new URL("../data/regulations.es.json", import.meta.url).pathname,
});
const calls = [];
let srv;
let mode = "ok";
before(async () => {
  srv = http.createServer((req, res) => {
    let body = "";
    req.on("data", (c) => (body += c));
    req.on("end", () => {
      const j = JSON.parse(body);
      calls.push(j);
      if (mode === "429") { res.writeHead(429); return res.end("{}"); }
      if (!j.stream) {
        res.setHeader("content-type", "application/json");
        return res.end(JSON.stringify({ choices: [{ message: { content: 'Claro: {"apartados": ["D.3.2", "Z.9"], "busquedas": ["battery container"]}' } }] }));
      }
      res.setHeader("content-type", "text/event-stream");
      res.write(`data: ${JSON.stringify({ choices: [{ delta: { content: [{ type: "thinking", thinking: [] }, { type: "text", text: "Sí [D.3.2.1]" }] } }] })}\n\n`);
      res.write(`data: ${JSON.stringify({ choices: [{ delta: { content: " y más." }, finish_reason: "length" }] })}\n\n`);
      res.end("data: [DONE]\n\n");
    });
  });
  await new Promise((r) => srv.listen(3979, r));
});
after(() => srv.close());

test("elige apartados del índice, arma los extractos y transmite la respuesta", async () => {
  const engine = createOpenAIEngine({ provider: "mistral", baseURL: "http://127.0.0.1:3979/v1", apiKey: "k", regs, rigor: "alto" });
  const events = [];
  await engine.answer({
    messages: [{ role: "user", content: "¿Cómo tiene que ser el contenedor de la batería?" }],
    lang: "es",
    send: (e, d) => events.push([e, d]),
    signal: new AbortController().signal,
  });
  const [planCall, answerCall] = calls;
  assert.equal(planCall.model, "mistral-medium-latest");
  assert.match(planCall.messages[0].content, /D\.3\.2 Contenedor de la Batería/);
  const system = answerCall.messages[0].content;
  assert.match(system, /### D\.3\.2 /);
  assert.match(system, /\[D\.3\.2\.1\] /);
  assert.ok(!system.includes("Z.9"), "ids inexistentes del plan se ignoran");
  assert.ok(system.length < 90000);
  const text = events.filter(([e]) => e === "text").map(([, d]) => d.delta).join("");
  assert.equal(text, "Sí [D.3.2.1] y más.");
  assert.ok(events.some(([e, d]) => e === "status" && d.status === "truncated"));
});

test("errores del plan gratuito con mensaje claro", async () => {
  mode = "429";
  const engine = createOpenAIEngine({ provider: "cerebras", baseURL: "http://127.0.0.1:3979/v1", apiKey: "k", regs, maxRetries: 0 });
  await assert.rejects(
    engine.answer({ messages: [{ role: "user", content: "hola" }], lang: "es", send() {}, signal: new AbortController().signal }),
    (e) => e.status === 429 && /límite gratuito de Cerebras/.test(friendlyLLMError(e, engine))
  );
  mode = "ok";
});

test("rigor máximo: lee todos los bloques, sigue referencias cruzadas, borrador y revisión", async () => {
  const seen = { blocks: 0, draft: null, review: null };
  const srv2 = http.createServer((req, res) => {
    let body = "";
    req.on("data", (c) => (body += c));
    req.on("end", () => {
      const j = JSON.parse(body);
      const content = j.messages.map((m) => m.content).join("\n");
      if (content.includes("<bloque>")) {
        seen.blocks++;
        const rel = content.includes("[E.5.2.3]") ? ["E.5.2.3", "NO.EXISTE"] : [];
        res.setHeader("content-type", "application/json");
        return res.end(JSON.stringify({ choices: [{ message: { content: JSON.stringify({ relevantes: rel }) } }] }));
      }
      if (!j.stream) {
        seen.draft = j.messages[0].content;
        res.setHeader("content-type", "application/json");
        return res.end(JSON.stringify({ choices: [{ message: { content: "Borrador con cita [E.5.2.3]." } }] }));
      }
      seen.review = content;
      res.setHeader("content-type", "text/event-stream");
      res.write(`data: ${JSON.stringify({ choices: [{ delta: { content: "Final [E.5.2.3]" } }] })}\n\n`);
      res.end("data: [DONE]\n\n");
    });
  });
  await new Promise((r) => srv2.listen(3980, r));
  try {
    const engine = createOpenAIEngine({ provider: "mistral", baseURL: "http://127.0.0.1:3980/v1", apiKey: "k", regs });
    assert.equal(engine.rigor, "max");
    const events = [];
    await engine.answer({ messages: [{ role: "user", content: "¿Cómo se mide el aislamiento?" }], lang: "es", send: (e, d) => events.push([e, d]), signal: new AbortController().signal });
    assert.equal(seen.blocks, engine.blocks, "se leen todos los bloques");
    assert.ok(engine.blocks >= 4);
    assert.match(seen.draft, /### E\.5\.2 /);
    assert.match(seen.draft, /### D\.7\.3 /, "se añade el apartado al que remite E.5.2.3 (Article D.7.3)");
    assert.match(seen.review, /BORRADOR:\nBorrador con cita/);
    assert.equal(events.filter(([e]) => e === "text").map(([, d]) => d.delta).join(""), "Final [E.5.2.3]");
    const scans = events.filter(([e, d]) => e === "status" && d.status === "scanning");
    assert.equal(scans.at(-1)[1].done, engine.blocks);
    assert.ok(events.some(([, d]) => d?.status === "reviewing"));
  } finally {
    srv2.close();
  }
});
