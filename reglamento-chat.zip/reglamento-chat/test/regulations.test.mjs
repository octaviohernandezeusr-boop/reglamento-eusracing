// npm test — comprobaciones básicas del reglamento procesado y del formato de citas
import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import vm from "node:vm";
import { loadRegulations, EFUEL_ONLY_IDS } from "../lib/regulations.js";

const regs = loadRegulations(new URL("../data/regulations.json", import.meta.url).pathname, { exclude: ["C"], excludeIds: EFUEL_ONLY_IDS, esPath: new URL("../data/regulations.es.json", import.meta.url).pathname });

test("el reglamento tiene todas las secciones y un volumen razonable", () => {
  assert.deepEqual(Object.keys(regs.doc.sections), ["A", "B", "D", "E", "F", "G", "H", "I", "J"]);
  const clauses = regs.doc.nodes.filter((n) => n.kind === "clause");
  assert.ok(clauses.length > 1150, `solo ${clauses.length} apartados`);
});

test("apartados conocidos con su texto y página", () => {
  const n = regs.byId.get("B.6.3.2");
  assert.match(n.text, /steel alloys/);
  assert.equal(n.page, 46);
  assert.equal(n.subsection, "B.6.3");
  assert.equal(regs.byId.get("B.6.7.1").text, "The use of anti-lock braking systems (ABS) is prohibited.");
  // Apartado que el PDF coloca tras la cabecera del artículo siguiente
  assert.equal(regs.byId.get("G.2.6.3").article, "G.2");
});

test("la Sección C (eFuel) no llega a la IA", () => {
  assert.ok(!regs.doc.nodes.some((n) => n.section === "C"));
  assert.ok(!regs.context.en.includes("SECTION C"));
  assert.ok(!regs.context.en.includes("[C.1."));
  for (const id of ["E.4", "E.4.1.1", "B.10.3.3", "G.3.4.4", "G.6.2.6"]) assert.ok(!regs.byId.has(id), id);
  // Se conserva porque G.6.2.5 (Electric) remite a él
  assert.ok(regs.byId.has("G.6.2.1") && regs.byId.has("G.6.2.5"));
});

test("el contexto para Claude incluye los identificadores entre corchetes", () => {
  assert.ok(regs.context.en.includes("[B.6.3.2] Brake discs must be manufactured from steel alloys."));
  assert.ok(regs.context.en.length < 600_000);
});

test("versión en español alineada con la numeración oficial", () => {
  const n = regs.byId.get("B.6.3.2");
  assert.match(n.es.text, /aleaciones de acero/);
  assert.equal(regs.byId.get("B.6.3").es.title, "Discos de Freno");
  assert.ok(regs.context.es.includes("[B.6.3.2] Los discos de freno deberán fabricarse en aleaciones de acero."));
  assert.ok(!regs.context.es.includes("SECCIÓN C"));
  // Cobertura: la gran mayoría de apartados tienen traducción fiable
  const withText = regs.doc.nodes.filter((x) => x.text);
  const translated = withText.filter((x) => x.es?.text);
  assert.ok(translated.length / withText.length > 0.9, `${translated.length}/${withText.length}`);
  // Los dudosos van en inglés y marcados
  const doubtful = withText.find((x) => !x.es?.text && x.kind === "clause");
  assert.ok(regs.context.es.includes(`[${doubtful.id}] {en inglés: sin traducción fiable}`));
});

test("el renderizador reconoce y valida las citas", () => {
  const sandbox = { window: {} };
  vm.runInNewContext(readFileSync(new URL("../public/markdown.js", import.meta.url), "utf-8"), sandbox);
  const { render } = sandbox.window.MD;
  const out = render("Prohibido [B.6.3.2] y [D.3.1.4, D.3.1.5] ver [Annex 5] y [Z.1] <script>", {
    isKnown: (id) => regs.byId.has(id),
  });
  assert.deepEqual([...out.cited], ["B.6.3.2", "D.3.1.4", "D.3.1.5", "Annex 5"]);
  assert.ok(!out.html.includes("<script>"), "debe escapar HTML");
});
