// Servidor falso con el formato de OpenAI (/chat/completions) para probar Mistral, Cerebras, Ollama…
// Uso: node test/fake-openai.mjs 3300   y luego LLM_BASE_URL=http://127.0.0.1:3300/v1
import http from "node:http";
import { writeFileSync } from "node:fs";

const port = Number(process.argv[2] || 3300);
const ANSWER = `**No.** Los discos deben ser de acero: _"Queda estrictamente prohibido el uso de discos de freno de carbono o cerámica."_ [B.6.3.2]. Tampoco se permiten discos ventilados internamente [B.6.3.4].`;
let n = 0;
http
  .createServer((req, res) => {
    let body = "";
    req.on("data", (c) => (body += c));
    req.on("end", async () => {
      const j = JSON.parse(body || "{}");
      writeFileSync(`/tmp/claude-0/oai-req-${++n}.json`, JSON.stringify({ auth: req.headers.authorization, url: req.url, ...j }, null, 1));
      if (process.env.FAIL === "429") {
        res.writeHead(429, { "content-type": "application/json" });
        return res.end('{"message":"Requests rate limit exceeded"}');
      }
      if (!j.stream) {
        const all = j.messages.map((m) => (typeof m.content === "string" ? m.content : "")).join("\n");
        let content;
        if (all.includes("<bloque>")) content = JSON.stringify({ relevantes: all.includes("[B.6.3.2]") ? ["B.6.3.2", "B.6.3.4"] : [] });
        else if (j.messages[0].role === "system") content = "Borrador: no se permite [B.6.3.2].";
        else content = '{"apartados": ["B.6.3", "B.6", "E.3"], "busquedas": ["discos de freno carbono", "brake disc carbon ceramic"]}';
        await new Promise((r) => setTimeout(r, 120));
        res.writeHead(200, { "content-type": "application/json" });
        return res.end(JSON.stringify({ choices: [{ message: { role: "assistant", content } }] }));
      }
      res.writeHead(200, { "content-type": "text/event-stream" });
      for (const chunk of ANSWER.match(/[\s\S]{1,18}/g)) {
        // Algunos proveedores (Mistral) mandan el contenido como lista de partes
        const content = n % 2 ? chunk : [{ type: "text", text: chunk }];
        res.write(`data: ${JSON.stringify({ choices: [{ index: 0, delta: { content } }] })}\n\n`);
        await new Promise((r) => setTimeout(r, 10));
      }
      res.write(`data: ${JSON.stringify({ choices: [{ index: 0, delta: {}, finish_reason: "stop" }] })}\n\n`);
      res.end("data: [DONE]\n\n");
    });
  })
  .listen(port, () => console.log("fake openai on", port));
