// Chat del reglamento MotoStudent — eUSRacing
(function () {
  "use strict";

  const $ = (s) => document.querySelector(s);
  const els = {
    messages: $("#messages"), empty: $("#empty"), examples: $("#examples"), folderHint: $("#folder-hint"),
    form: $("#composer"), input: $("#input"), send: $("#send"),
    revision: $("#revision"), revInline: $("#rev-inline"), codeDialog: $("#code-dialog"),
    login: $("#login"), loginError: $("#login-error"), sbFoot: $("#sb-foot"),
  };

  const EXAMPLES = [
    { q: "¿Se pueden usar discos de freno de carbono o cerámicos?", tag: "Frenos" },
    { q: "¿Qué tensión máxima se permite en el sistema de alta tensión?", tag: "Electric" },
    { q: "¿Qué requisitos tiene que cumplir el piloto para poder competir?", tag: "Piloto" },
    { q: "¿Qué pasa si entregamos tarde un entregable de un hito?", tag: "Hitos" },
    { q: "¿Cómo tienen que ser los cables de alta tensión y su aislamiento?", tag: "Electric" },
    { q: "¿Qué pruebas hay en las verificaciones técnicas (scrutineering)?", tag: "Verificaciones" },
  ];

  const store = {
    get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* sin almacenamiento */ } },
    del(k) { try { localStorage.removeItem(k); } catch { /* nada */ } },
  };
  const PREFS = "eus-reg-prefs-v1";
  const prefs = store.get(PREFS, {});

  const state = {
    conv: newConv(),
    lang: prefs.lang === "en" ? "en" : "es",
    code: store.get("eus-reg-code", ""),
    config: {},
    user: null,
    regs: new Map(),
    nodes: [],
    ctl: null,
    busy: false,
  };
  let explorer = null;
  let library = null;
  let adapter = null;

  function newConv(folderId = null) {
    return { id: RegLibrary.newId(), title: "", folderId, messages: [], saved: false };
  }
  const savePrefs = () => store.set(PREFS, { lang: state.lang, lastConv: prefs.lastConv || null });
  const headers = () => ({ "Content-Type": "application/json", ...(state.code ? { "X-Access-Code": state.code } : {}) });

  // ---------------------------------------------------------------- arranque
  async function init() {
    renderExamples();
    setLang(state.lang, false);
    autosize();
    try {
      state.config = await (await fetch("api/config")).json();
    } catch {
      toast("No se puede conectar con el servidor. ¿Está arrancado?");
      return;
    }
    const cfg = state.config;
    if (cfg.revision) {
      els.revision.textContent = `MS2627 Electric · ${cfg.revision}${cfg.mock ? " · DEMO" : ""}`;
      els.revInline.textContent = `MS2627 ${cfg.revision}${cfg.engine && !cfg.mock ? ` · ${cfg.engine}` : ""}`;
    }
    if (cfg.auth?.mode === "oauth") {
      state.user = (await (await fetch("api/me")).json()).user;
      if (!state.user) return showLogin(cfg.auth);
    } else if (cfg.auth?.mode === "code") {
      if (!(await codeIsValid(state.code))) await askCode();
    }
    await start();
  }

  async function start() {
    els.login.hidden = true;
    document.body.classList.remove("needs-login");
    adapter = state.config.library === "server" ? RegLibrary.serverAdapter(headers) : RegLibrary.browserAdapter();
    library = RegLibrary.create({
      adapter,
      getActiveId: () => (state.conv.saved ? state.conv.id : null),
      onOpen: openConversation,
      onNew: (folderId) => newConversation(folderId),
      onDeleted: (id) => { if (state.conv.id === id) newConversation(null); },
      toast,
    });
    library.onRenamed = (id, title) => { if (state.conv.id === id) state.conv.title = title; };
    renderUser();
    await Promise.all([loadRegulations(), library.refresh()]);
    if (prefs.lastConv) await openConversation(prefs.lastConv, true);
    else renderAll();
    els.input.focus();
  }

  function renderUser() {
    const cfg = state.config;
    if (cfg.auth?.mode === "oauth" && state.user) {
      const u = state.user;
      const avatar = u.picture
        ? `<img class="sb-avatar" src="${MD.esc(u.picture)}" alt="" referrerpolicy="no-referrer">`
        : `<span class="sb-avatar">${MD.esc((u.name || u.email || "?").charAt(0).toUpperCase())}</span>`;
      els.sbFoot.innerHTML = `${avatar}<div class="sb-user"><strong>${MD.esc(u.name)}</strong><small>${MD.esc(u.email)}</small></div>
        <button type="button" class="x-nb" id="btn-logout" title="Cerrar sesión" aria-label="Cerrar sesión"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M15 17l5-5-5-5M20 12H9M12 20H5a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1h7" /></svg></button>`;
      $("#btn-logout").onclick = async () => {
        await fetch("auth/logout", { method: "POST" }).catch(() => {});
        store.set(PREFS, { lang: state.lang });
        location.reload();
      };
    } else {
      els.sbFoot.innerHTML = `<p class="sb-note">${adapter.kind === "server" ? "Conversaciones guardadas en el servidor (uso local, sin login)." : "Conversaciones guardadas en este navegador."}</p>`;
    }
  }

  // ---------------------------------------------------------------- login
  function showLogin(auth) {
    els.login.hidden = false;
    document.body.classList.add("needs-login");
    const fail = (msg) => { els.loginError.hidden = false; els.loginError.textContent = msg; };
    let nonce = null;
    const post = async (provider, body) => {
      els.loginError.hidden = true;
      try {
        const r = await fetch(`auth/${provider}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
        const j = await r.json().catch(() => ({}));
        if (!r.ok) throw new Error(j.error || "No se pudo iniciar sesión.");
        state.user = j.user;
        await start();
      } catch (e) {
        fail(e.message);
        prepare(); // nonce nuevo para el siguiente intento
      }
    };
    async function prepare() {
      nonce = (await (await fetch("auth/nonce")).json()).nonce;
      if (auth.google && window.google?.accounts?.id) {
        google.accounts.id.initialize({ client_id: auth.google, nonce, callback: (r) => post("google", { idToken: r.credential }), ux_mode: "popup", context: "signin", itp_support: true });
      }
      if (auth.apple && window.AppleID) {
        AppleID.auth.init({ clientId: auth.apple.clientId, scope: "name email", redirectURI: auth.apple.redirectURI || location.origin + location.pathname, nonce, state: nonce.slice(0, 12), usePopup: true });
      }
    }
    const load = (src) => new Promise((ok, ko) => { const s = document.createElement("script"); s.src = src; s.async = true; s.onload = ok; s.onerror = ko; document.head.appendChild(s); });
    (async () => {
      const jobs = [];
      if (auth.google) jobs.push(load("https://accounts.google.com/gsi/client").catch(() => fail("No se pudo cargar el acceso con Google.")));
      if (auth.apple) jobs.push(load("https://appleid.cdn-apple.com/appleauth/static/jsapi/appleid/1/es_ES/appleid.auth.js").catch(() => fail("No se pudo cargar el acceso con Apple.")));
      await Promise.all(jobs);
      // El botón de Apple se dibuja al llamar a AppleID.auth.init: el contenedor debe estar visible
      if (auth.apple && window.AppleID) $("#appleid-signin").hidden = false;
      await prepare().catch(() => fail("No se puede conectar con el servidor."));
      if (auth.google && window.google?.accounts?.id) {
        const el = $("#google-btn");
        el.hidden = false;
        google.accounts.id.renderButton(el, { theme: "outline", size: "large", text: "continue_with", shape: "rectangular", width: 300, locale: "es" });
      }
    })();
    document.addEventListener("AppleIDSignInOnSuccess", (e) => {
      const d = e.detail || {};
      post("apple", { idToken: d.authorization?.id_token, user: d.user || null });
    });
    document.addEventListener("AppleIDSignInOnFailure", (e) => {
      if (e.detail?.error !== "popup_closed_by_user") fail("No se pudo iniciar sesión con Apple.");
    });
  }

  async function codeIsValid(code) {
    if (!code) return false;
    try {
      const r = await fetch("api/check-code", { method: "POST", headers: { "X-Access-Code": code } });
      return (await r.json()).ok;
    } catch { return false; }
  }
  function askCode() {
    return new Promise((resolve) => {
      const input = $("#code-input");
      const err = $("#code-error");
      els.codeDialog.showModal();
      $("#code-form").onsubmit = async (e) => {
        e.preventDefault();
        const code = input.value.trim();
        if (await codeIsValid(code)) {
          state.code = code;
          store.set("eus-reg-code", code);
          els.codeDialog.close();
          resolve();
        } else {
          err.hidden = false;
          input.select();
        }
      };
      els.codeDialog.addEventListener("cancel", (e) => e.preventDefault());
    });
  }

  async function loadRegulations() {
    try {
      const r = await fetch("api/regulations", { headers: headers() });
      if (!r.ok) throw new Error(r.status);
      const data = await r.json();
      state.nodes = data.nodes;
      state.regs = new Map(data.nodes.map((n) => [n.id, n]));
      explorer = RegExplorer.create({
        nodes: state.nodes,
        sections: data.sections,
        revision: data.revision,
        lang: state.lang,
        onAsk(id) {
          els.input.value = `Explícame el apartado ${id}: qué exige y cómo nos afecta.`;
          autosize();
          els.input.focus();
          els.input.setSelectionRange(els.input.value.length, els.input.value.length);
        },
      });
    } catch {
      toast("No se pudo cargar el reglamento: las citas no mostrarán el texto.");
    }
  }

  // ---------------------------------------------------------------- conversaciones
  async function openConversation(id, silent) {
    if (state.busy) state.ctl?.abort();
    try {
      const c = await adapter.get(id);
      state.conv = { id: c.id, title: c.title, folderId: c.folderId || null, messages: c.messages || [], saved: true };
      prefs.lastConv = c.id;
    } catch (e) {
      if (!silent) toast(e.message);
      state.conv = newConv();
      prefs.lastConv = null;
    }
    savePrefs();
    renderAll();
    library?.render();
    requestAnimationFrame(() => window.scrollTo({ top: document.body.scrollHeight }));
  }
  function newConversation(folderId) {
    if (state.busy) state.ctl?.abort();
    state.conv = newConv(folderId || null);
    prefs.lastConv = null;
    savePrefs();
    renderAll();
    library?.render();
    explorer?.close();
    els.input.focus();
  }
  async function persistConv(c) {
    if (!c.title) {
      const first = c.messages.find((m) => m.role === "user")?.content || "Conversación";
      c.title = first.length > 60 ? first.slice(0, 57).trimEnd() + "…" : first;
    }
    try {
      const meta = await adapter.save({ id: c.id, title: c.title, folderId: c.folderId, messages: c.messages.map(({ role, content, error }) => ({ role, content, ...(error ? { error } : {}) })) });
      c.saved = true;
      if (c === state.conv) { prefs.lastConv = c.id; savePrefs(); }
      library.upsert(meta);
    } catch (e) {
      toast("No se pudo guardar la conversación: " + e.message);
    }
  }

  // ---------------------------------------------------------------- mensajes
  function renderExamples() {
    els.examples.innerHTML = "";
    for (const ex of EXAMPLES) {
      const b = document.createElement("button");
      b.type = "button";
      b.className = "example";
      b.innerHTML = `<span class="example-tag">${MD.esc(ex.tag)}</span><span>${MD.esc(ex.q)}</span>`;
      b.onclick = () => ask(ex.q);
      els.examples.appendChild(b);
    }
  }

  function renderAll() {
    els.messages.innerHTML = "";
    state.conv.messages.forEach((m) => els.messages.appendChild(renderMessage(m)));
    const empty = state.conv.messages.length === 0;
    els.empty.hidden = !empty;
    const fname = state.conv.folderId && library?.folderName(state.conv.folderId);
    els.folderHint.hidden = !(empty && fname);
    if (fname) els.folderHint.textContent = `Se guardará en la carpeta «${fname}»`;
  }

  function renderMessage(m) {
    const wrap = document.createElement("article");
    wrap.className = `msg msg-${m.role}`;
    if (m.role === "user") {
      const b = document.createElement("div");
      b.className = "bubble";
      b.textContent = m.content;
      wrap.appendChild(b);
      return wrap;
    }
    wrap.innerHTML = `
      <div class="avatar" aria-hidden="true"><img src="logo.png" class="logo-color" alt=""><img src="logo-blanco.png" class="logo-white" alt=""></div>
      <div class="answer">
        <div class="md"></div>
        <div class="status" hidden></div>
        <div class="sources" hidden></div>
        <div class="msg-actions" hidden>
          <button type="button" class="ghost" data-act="copy">Copiar</button>
        </div>
      </div>`;
    updateAssistant(wrap, m, true);
    wrap.querySelector('[data-act="copy"]').onclick = (e) => copyAnswer(m, e.currentTarget);
    return wrap;
  }

  const isKnown = (id) => state.regs.size === 0 || state.regs.has(id);
  const T = (n) => (state.lang === "es" && n?.es?.title) || n?.title || "";
  const X = (n) => (state.lang === "es" && n?.es?.text) || n?.text || "";
  const titleCase = (s) => (s ? s.charAt(0) + s.slice(1).toLowerCase() : "");
  const nice = (n) => { const t = T(n); return t === t.toUpperCase() ? titleCase(t) : t; };

  function updateAssistant(wrap, m, final) {
    const md = wrap.querySelector(".md");
    const status = wrap.querySelector(".status");
    const { html, cited, quotes } = MD.render(m.content || "", { isKnown, verifyQuote });
    md.innerHTML = html;
    m.cited = cited;
    m.quotes = quotes;
    status.className = "status";
    if (!m.content && !m.error && !final) {
      status.hidden = false;
      status.innerHTML = `<span class="dots"><i></i><i></i><i></i></span> <span>${MD.esc(m.stage || "Consultando el reglamento…")}</span>`;
    } else if (m.error) {
      status.hidden = false;
      status.className = "status status-error";
      status.textContent = m.error;
    } else if (m.unreviewed) {
      status.hidden = false;
      status.className = "status status-warn";
      status.textContent = "Esta respuesta no se ha podido revisar con el reglamento. Comprueba bien los apartados citados.";
    } else if (m.truncated) {
      status.hidden = false;
      status.className = "status status-warn";
      status.textContent = "La respuesta se ha cortado por longitud. Pide que continúe o haz una pregunta más concreta.";
    } else {
      status.hidden = true;
    }
    if (final) {
      renderSources(wrap.querySelector(".sources"), cited, quotes);
      wrap.querySelector(".msg-actions").hidden = !m.content;
    }
  }

  function nodeHeading(n) {
    if (n.kind === "clause") return T(state.regs.get(n.subsection)) || nice(state.regs.get(n.article));
    return nice(n);
  }
  function childrenOf(n) {
    if (n.kind === "subsection") return state.nodes.filter((c) => c.subsection === n.id && c.kind === "clause");
    if (n.kind === "article") return state.nodes.filter((c) => c.article === n.id && c.kind === "subsection");
    return [];
  }

  // ¿La frase entre comillas está tal cual en el apartado citado (en español o en inglés)?
  function verifyQuote(id, quote) {
    const n = state.regs.get(id);
    if (!n) return null;
    const texts = [];
    const take = (x) => { if (x?.text) texts.push(x.text); if (x?.es?.text) texts.push(x.es.text); };
    take(n);
    for (const c of childrenOf(n)) { take(c); childrenOf(c).forEach(take); }
    return MD.quoteIn(quote, texts);
  }
  function quoteSummary(quotes = []) {
    const ok = quotes.filter((q) => q.ok).length;
    const bad = quotes.length - ok;
    if (!quotes.length) return "";
    return `<p class="quote-check">${ok ? `<span class="qc-ok">✓ ${ok} ${ok === 1 ? "cita literal comprobada" : "citas literales comprobadas"}</span>` : ""}${bad ? `<span class="qc-bad">⚠ ${bad} ${bad === 1 ? "cita no coincide" : "citas no coinciden"} con el texto: revísalas</span>` : ""}</p>`;
  }

  function renderSources(box, cited, quotes) {
    const known = cited.filter((id) => state.regs.has(id));
    const unknown = cited.filter((id) => state.regs.size && !state.regs.has(id));
    if (!cited.length) { box.hidden = true; return; }
    box.hidden = false;
    const cards = known.map((id) => {
      const n = state.regs.get(id);
      const preview = X(n) || childrenOf(n).map((c) => X(c)).filter(Boolean).join(" ") || "";
      return `<button type="button" class="source" data-id="${MD.esc(id)}">
          <span class="source-top"><span class="source-id">${MD.esc(id)}</span><span class="source-page">${n.page ? "pág. " + n.page : ""}</span></span>
          <span class="source-title">${MD.esc(nodeHeading(n) || "")}</span>
          <span class="source-text">${MD.esc(preview.slice(0, 220))}${preview.length > 220 ? "…" : ""}</span>
        </button>`;
    }).join("");
    const warn = unknown.length
      ? `<p class="source-warn">⚠ ${unknown.map(MD.esc).join(", ")} no aparece${unknown.length > 1 ? "n" : ""} en el reglamento. Compruébalo en el PDF.</p>`
      : "";
    box.innerHTML = `<details ${known.length <= 4 ? "open" : ""}>
        <summary>Apartados citados <span class="count">${known.length}</span></summary>
        <div class="source-grid">${cards}</div>${warn}</details>${quoteSummary(quotes)}`;
  }

  async function copyAnswer(m, btn) {
    let text = m.content;
    const known = (m.cited || []).filter((id) => state.regs.has(id));
    if (known.length) {
      text += "\n\n— Apartados citados (MotoStudent MS2627) —\n" +
        known.map((id) => { const n = state.regs.get(id); return `${id}${n.page ? ` (pág. ${n.page})` : ""}: ${X(n) || nodeHeading(n)}`; }).join("\n");
    }
    try {
      await navigator.clipboard.writeText(text);
      btn.textContent = "¡Copiado!";
    } catch {
      btn.textContent = "No se pudo copiar";
    }
    setTimeout(() => (btn.textContent = "Copiar"), 1600);
  }

  // ---------------------------------------------------------------- enviar
  function ask(text) {
    els.input.value = text;
    els.form.requestSubmit();
  }

  els.form.addEventListener("submit", async (e) => {
    e.preventDefault();
    if (state.busy) { state.ctl?.abort(); return; }
    if (!adapter) return;
    const q = els.input.value.trim();
    if (!q) return;
    els.input.value = "";
    autosize();

    const conv = state.conv;
    // Historial: solo turnos completos (sin errores ni respuestas vacías)
    const history = [];
    for (const m of conv.messages) {
      if (m.role === "assistant" && (!m.content || m.error)) { history.pop(); continue; }
      history.push({ role: m.role, content: m.content });
    }
    history.push({ role: "user", content: q });

    const user = { role: "user", content: q };
    const bot = { role: "assistant", content: "" };
    conv.messages.push(user, bot);
    els.empty.hidden = true;
    els.messages.appendChild(renderMessage(user));
    const wrap = renderMessage(bot);
    els.messages.appendChild(wrap);
    updateAssistant(wrap, bot, false);
    wrap.scrollIntoView({ behavior: "smooth", block: "start" });

    setBusy(true);
    const ctl = new AbortController();
    state.ctl = ctl;
    let raf = 0;
    const paint = () => { raf = 0; if (state.conv === conv) updateAssistant(wrap, bot, false); };
    try {
      const res = await fetch("api/chat", {
        method: "POST",
        headers: headers(),
        body: JSON.stringify({ messages: history, lang: state.lang }),
        signal: ctl.signal,
      });
      if (!res.ok) {
        const j = await res.json().catch(() => ({}));
        if (res.status === 401 && state.config.auth?.mode === "code") { store.del("eus-reg-code"); state.code = ""; }
        throw new Error(j.error || `Error ${res.status}`);
      }
      await readSSE(res, (event, data) => {
        if (event === "text") {
          bot.content += data.delta;
          if (!raf) raf = requestAnimationFrame(paint);
        } else if (event === "status") {
          const st = data.status;
          if (st === "scanning") bot.stage = `Leyendo el reglamento completo… bloque ${data.done} de ${data.total}`;
          else if (st === "planning") bot.stage = "Buscando los artículos relevantes…";
          else if (st === "drafting") bot.stage = "Redactando la respuesta con los apartados encontrados…";
          else if (st === "reviewing") bot.stage = "Revisando cada afirmación contra el reglamento…";
          else if (st === "thinking") bot.stage = "Redactando la respuesta…";
          else if (st === "waiting") bot.stage = `Límite del plan gratuito: esperando ${data.seconds} s para seguir…`;
          else if (st === "unreviewed") bot.unreviewed = true;
          else if (st === "truncated") bot.truncated = true;
          paint();
        } else if (event === "error") {
          bot.error = data.error;
        }
      });
      if (!bot.content && !bot.error) bot.error = "No se recibió respuesta. Inténtalo de nuevo.";
    } catch (err) {
      if (ctl.signal.aborted) {
        if (!bot.content) bot.error = "Detenido.";
        else bot.content += "\n\n_(respuesta detenida)_";
      } else {
        bot.error = err.message && !/fetch|network/i.test(err.message) ? err.message : "No se puede conectar con el servidor.";
      }
    } finally {
      if (raf) cancelAnimationFrame(raf);
      delete bot.stage;
      if (state.conv === conv) updateAssistant(wrap, bot, true);
      setBusy(false);
      await persistConv(conv);
    }
  });

  async function readSSE(res, onEvent) {
    const reader = res.body.getReader();
    const dec = new TextDecoder();
    let buf = "";
    for (;;) {
      const { value, done } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      let idx;
      while ((idx = buf.indexOf("\n\n")) >= 0) {
        const chunk = buf.slice(0, idx);
        buf = buf.slice(idx + 2);
        let event = "message";
        let data = "";
        for (const line of chunk.split("\n")) {
          if (line.startsWith("event:")) event = line.slice(6).trim();
          else if (line.startsWith("data:")) data += line.slice(5).trim();
        }
        if (data) {
          try { onEvent(event, JSON.parse(data)); } catch { /* evento malformado */ }
        }
      }
    }
  }

  function setBusy(b) {
    state.busy = b;
    els.send.classList.toggle("is-stop", b);
    els.send.setAttribute("aria-label", b ? "Parar" : "Enviar");
  }

  // ---------------------------------------------------------------- idioma
  function setLang(lang, save = true) {
    state.lang = lang === "en" ? "en" : "es";
    document.querySelectorAll(".segmented [data-lang]").forEach((b) => b.setAttribute("aria-checked", String(b.dataset.lang === state.lang)));
    document.documentElement.dataset.regLang = state.lang;
    explorer?.setLang(state.lang);
    if (save) { savePrefs(); renderAll(); }
  }
  document.querySelectorAll(".segmented [data-lang]").forEach((b) => (b.onclick = () => setLang(b.dataset.lang)));

  // ---------------------------------------------------------------- eventos
  document.addEventListener("click", (e) => {
    const cite = e.target.closest(".cite, .source");
    if (cite && explorer) return explorer.open(cite.dataset.id);
  });
  $("#btn-explore").onclick = () => explorer?.toggle();
  $("#btn-new").onclick = () => newConversation(null);

  function autosize() {
    els.input.style.height = "auto";
    els.input.style.height = Math.min(els.input.scrollHeight, 200) + "px";
  }
  els.input.addEventListener("input", autosize);
  els.input.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey && !e.isComposing) {
      e.preventDefault();
      if (!state.busy) els.form.requestSubmit();
    }
  });

  function toast(msg) {
    const t = document.createElement("div");
    t.className = "toast";
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(() => t.remove(), 6000);
  }

  init();
})();
