// Renderizador Markdown mínimo y seguro (todo se escapa antes de dar formato),
// con soporte para las citas del reglamento: [B.6.3.2], [Annex 5], [D.3.1.4, D.3.1.5]...
(function () {
  const ID = String.raw`(?:[A-J]\.\d+(?:\.\d+){0,3}(?: \(\d\))?|Annex \d+|Anexo \d+)`;
  // Corchete con uno o varios ids separados por coma, punto y coma, "y", "and" o guion (rango)
  const CITE_RE = new RegExp(String.raw`\[(${ID}(?:\s*(?:,|;|–|-|y|and)\s*${ID})*)\]`, "g");
  const ID_RE = new RegExp(ID, "g");

  const esc = (s) =>
    s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

  // Frase entre comillas justo antes de una cita: _"texto"_ [ID], «texto» [ID], “texto” [ID]
  const UNESC = (t) => t.replace(/&quot;/g, '"').replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&amp;/g, "&");
  function quoteBefore(before) {
    let t = before.replace(/[\s_*]+$/, "");
    if (!/(&quot;|”|»)$/.test(t)) t = t.replace(/[.,;:)]$/, "").replace(/[\s_*]+$/, "");
    const pairs = [["&quot;", "&quot;"], ["”", "“"], ["»", "«"]];
    for (const [close, open] of pairs) {
      if (!t.endsWith(close)) continue;
      const end = t.length - close.length;
      const start = t.lastIndexOf(open, end - 1);
      if (start < 0) return null;
      const q = UNESC(t.slice(start + open.length, end)).trim();
      return q.length >= 12 ? q : null;
    }
    return null;
  }

  function normId(id) {
    return id.replace(/^Anexo/, "Annex");
  }

  function inline(text, ctx) {
    // Proteger código en línea
    const codes = [];
    let s = text.replace(/`([^`]+)`/g, (_, c) => {
      codes.push(c);
      return `\u0000${codes.length - 1}\u0000`;
    });
    s = esc(s);
    // Citas (y comprobación de la frase literal que las precede, si la hay)
    s = s.replace(CITE_RE, (_, inner, offset, whole) => {
      const ids = (inner.match(ID_RE) || []).map(normId);
      const quote = quoteBefore(whole.slice(Math.max(0, offset - 900), offset));
      let verdict = null;
      if (quote && ctx.verifyQuote) {
        const results = ids.map((id) => ctx.verifyQuote(id, quote));
        verdict = results.includes(true) ? true : results.includes(false) ? false : null;
        if (verdict !== null) ctx.quotes.push({ ids, ok: verdict });
      }
      return ids
        .map((id, i) => {
          ctx.cited.push(id);
          const known = ctx.isKnown(id);
          const v = i === 0 ? verdict : null;
          const cls = !known ? " cite-unknown" : v === true ? " cite-ok" : v === false ? " cite-bad" : "";
          const title = !known
            ? "Este apartado no existe en el reglamento: compruébalo"
            : v === true
              ? `La frase entre comillas aparece literalmente en ${id}`
              : v === false
                ? `La frase entre comillas no aparece tal cual en ${id}: revísalo`
                : "Ver apartado " + id;
          return `<button type="button" class="cite${cls}" data-id="${esc(id)}" title="${esc(title)}">${esc(id)}</button>`;
        })
        .join("");
    });
    // Negrita, cursiva
    s = s.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
    s = s.replace(/__([^_]+)__/g, "<strong>$1</strong>");
    s = s.replace(/(^|[\s(“"«])\*([^*\s][^*]*?)\*(?=[\s).,;:!?”"»]|$)/g, "$1<em>$2</em>");
    s = s.replace(/(^|[\s(“"«])_([^_\s][^_]*?)_(?=[\s).,;:!?”"»]|$)/g, "$1<em>$2</em>");
    // Enlaces [texto](https://...)
    s = s.replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
    s = s.replace(/\u0000(\d+)\u0000/g, (_, i) => `<code>${esc(codes[+i])}</code>`);
    return s;
  }

  function render(md, opts = {}) {
    const ctx = { cited: [], quotes: [], isKnown: opts.isKnown || (() => true), verifyQuote: opts.verifyQuote || null };
    const lines = md.replace(/\r\n/g, "\n").split("\n");
    const html = [];
    let i = 0;
    let para = [];
    const flushPara = () => {
      if (para.length) html.push(`<p>${inline(para.join(" "), ctx)}</p>`);
      para = [];
    };

    while (i < lines.length) {
      const line = lines[i];
      const t = line.trim();

      if (!t) { flushPara(); i++; continue; }

      // Bloque de código
      if (t.startsWith("```")) {
        flushPara();
        const buf = [];
        i++;
        while (i < lines.length && !lines[i].trim().startsWith("```")) buf.push(lines[i++]);
        i++;
        html.push(`<pre><code>${esc(buf.join("\n"))}</code></pre>`);
        continue;
      }
      // Encabezados
      const h = t.match(/^(#{1,4})\s+(.*)$/);
      if (h) {
        flushPara();
        const lvl = Math.min(h[1].length + 2, 6);
        html.push(`<h${lvl}>${inline(h[2], ctx)}</h${lvl}>`);
        i++;
        continue;
      }
      // Separador
      if (/^(-{3,}|\*{3,})$/.test(t)) { flushPara(); html.push("<hr>"); i++; continue; }
      // Cita en bloque
      if (t.startsWith(">")) {
        flushPara();
        const buf = [];
        while (i < lines.length && lines[i].trim().startsWith(">")) buf.push(lines[i++].trim().replace(/^>\s?/, ""));
        const inner = render(buf.join("\n"), opts);
        html.push(`<blockquote>${inner.html}</blockquote>`);
        ctx.cited.push(...inner.cited);
        ctx.quotes.push(...inner.quotes);
        continue;
      }
      // Tabla GFM
      if (t.startsWith("|") && i + 1 < lines.length && /^\|?\s*:?-{2,}/.test(lines[i + 1].trim())) {
        flushPara();
        const row = (l) => l.trim().replace(/^\|/, "").replace(/\|$/, "").split("|").map((c) => c.trim());
        const head = row(lines[i]);
        i += 2;
        const body = [];
        while (i < lines.length && lines[i].trim().startsWith("|")) body.push(row(lines[i++]));
        html.push(
          `<div class="table-wrap"><table><thead><tr>${head.map((c) => `<th>${inline(c, ctx)}</th>`).join("")}</tr></thead><tbody>${body
            .map((r) => `<tr>${r.map((c) => `<td>${inline(c, ctx)}</td>`).join("")}</tr>`)
            .join("")}</tbody></table></div>`
        );
        continue;
      }
      // Listas (con un nivel de anidación por sangría)
      const li = line.match(/^(\s*)([-*•]|\d+[.)])\s+(.*)$/);
      if (li) {
        flushPara();
        const ordered = /\d/.test(li[2]);
        const items = [];
        while (i < lines.length) {
          const m = lines[i].match(/^(\s*)([-*•]|\d+[.)])\s+(.*)$/);
          if (m) {
            if (m[1].length >= 2 && items.length) items[items.length - 1].sub.push(m[3]);
            else items.push({ text: m[3], sub: [] });
            i++;
          } else if (lines[i].trim() && /^\s{2,}/.test(lines[i]) && items.length) {
            items[items.length - 1].text += " " + lines[i].trim();
            i++;
          } else break;
        }
        const tag = ordered ? "ol" : "ul";
        html.push(
          `<${tag}>${items
            .map(
              (it) =>
                `<li>${inline(it.text, ctx)}${
                  it.sub.length ? `<ul>${it.sub.map((s) => `<li>${inline(s, ctx)}</li>`).join("")}</ul>` : ""
                }</li>`
            )
            .join("")}</${tag}>`
        );
        continue;
      }
      para.push(t);
      i++;
    }
    flushPara();
    return { html: html.join("\n"), cited: [...new Set(ctx.cited)], quotes: ctx.quotes };
  }

  // Comprobación literal: normaliza (minúsculas, sin tildes ni signos) y busca cada trozo de la cita
  const norm = (t) => String(t || "").toLowerCase().normalize("NFKD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9%]+/g, " ").trim();
  function quoteIn(quote, texts) {
    const parts = quote.split(/\.\.\.|…|\[…\]|\(…\)/).map(norm).filter((p) => p.split(" ").length >= 3);
    if (!parts.length) return null;
    const hay = texts.map(norm).join(" ");
    return parts.every((p) => hay.includes(p));
  }

  window.MD = { render, esc, quoteIn };
})();
