// Historial de conversaciones con carpetas (barra lateral).
// Dos almacenes con la misma interfaz: en el servidor (por usuario) o en este navegador.
(function () {
  "use strict";

  const esc = (s) =>
    String(s ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  const newId = () =>
    (crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).slice(2) + Date.now().toString(36)).replace(/-/g, "").slice(0, 20);

  // ------------------------------------------------------------ almacenes
  function serverAdapter(headers) {
    const call = async (method, path, body) => {
      const r = await fetch(`api${path}`, { method, headers: { "Content-Type": "application/json", ...headers() }, body: body ? JSON.stringify(body) : undefined });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(j.error || `Error ${r.status}`);
      return j;
    };
    return {
      kind: "server",
      list: () => call("GET", "/library"),
      get: (id) => call("GET", `/conversations/${encodeURIComponent(id)}`),
      save: (c) => call("PUT", `/conversations/${encodeURIComponent(c.id)}`, { title: c.title, folderId: c.folderId ?? null, messages: c.messages }),
      patch: (id, p) => call("PUT", `/conversations/${encodeURIComponent(id)}`, p),
      remove: (id) => call("DELETE", `/conversations/${encodeURIComponent(id)}`),
      createFolder: (name) => call("POST", "/folders", { name }),
      renameFolder: (id, name) => call("PATCH", `/folders/${encodeURIComponent(id)}`, { name }),
      deleteFolder: (id) => call("DELETE", `/folders/${encodeURIComponent(id)}`),
    };
  }

  function browserAdapter(key = "eus-reg-library-v1") {
    const load = () => {
      try {
        const v = JSON.parse(localStorage.getItem(key) || "null");
        return { folders: v?.folders || [], conversations: v?.conversations || {} };
      } catch { return { folders: [], conversations: {} }; }
    };
    const save = (db) => { try { localStorage.setItem(key, JSON.stringify(db)); } catch { throw new Error("No se pudo guardar en este navegador (almacenamiento lleno o bloqueado)."); } };
    const meta = ({ messages, ...m }) => ({ ...m, count: messages?.length || 0 });
    const now = () => new Date().toISOString();
    return {
      kind: "browser",
      async list() {
        const db = load();
        return { folders: db.folders, conversations: Object.values(db.conversations).map(meta).sort((a, b) => (b.updatedAt || "").localeCompare(a.updatedAt || "")) };
      },
      async get(id) {
        const c = load().conversations[id];
        if (!c) throw new Error("Conversación no encontrada");
        return c;
      },
      async save(c) {
        const db = load();
        const cur = db.conversations[c.id];
        db.conversations[c.id] = { createdAt: cur?.createdAt || now(), ...cur, id: c.id, title: c.title, folderId: c.folderId ?? null, messages: c.messages, updatedAt: now() };
        save(db);
        return meta(db.conversations[c.id]);
      },
      async patch(id, p) {
        const db = load();
        const c = db.conversations[id];
        if (!c) throw new Error("Conversación no encontrada");
        if ("title" in p) c.title = p.title;
        if ("folderId" in p) c.folderId = p.folderId;
        save(db);
        return meta(c);
      },
      async remove(id) { const db = load(); delete db.conversations[id]; save(db); return { ok: true }; },
      async createFolder(name) { const db = load(); const f = { id: "f_" + newId().slice(0, 8), name: name || "Carpeta nueva", createdAt: now() }; db.folders.push(f); save(db); return f; },
      async renameFolder(id, name) { const db = load(); const f = db.folders.find((x) => x.id === id); if (f) f.name = name; save(db); return f; },
      async deleteFolder(id) {
        const db = load();
        db.folders = db.folders.filter((x) => x.id !== id);
        for (const c of Object.values(db.conversations)) if (c.folderId === id) c.folderId = null;
        save(db);
        return { ok: true };
      },
    };
  }

  // ------------------------------------------------------------ interfaz
  function create({ adapter, onOpen, onNew, onDeleted, getActiveId, toast, storageKey = "eus-reg-sidebar-v1" }) {
    const $ = (s) => document.querySelector(s);
    const els = { sidebar: $("#sidebar"), list: $("#sb-list"), filter: $("#sb-filter"), newBtn: $("#sb-new"), toggle: $("#btn-sidebar"), backdrop: $("#sb-backdrop") };
    let folders = [];
    let convs = [];
    let collapsed = new Set();
    let editing = null; // {type:'folder'|'conv'|'newFolder', id}
    let menu = null; // {type, id}
    let confirmDelete = null;
    let dragId = null;
    try {
      const s = JSON.parse(localStorage.getItem(storageKey) || "{}");
      collapsed = new Set(s.collapsed || []);
      if (s.open === false || (s.open === undefined && window.innerWidth < 1100)) setOpen(false, false);
      else setOpen(true, false);
    } catch { setOpen(window.innerWidth >= 1100, false); }
    const persist = () => { try { localStorage.setItem(storageKey, JSON.stringify({ collapsed: [...collapsed], open: isOpen() })); } catch { /* nada */ } };

    function isOpen() { return document.body.classList.contains("sidebar-open"); }
    function setOpen(open, save = true) {
      document.body.classList.toggle("sidebar-open", open);
      els.toggle?.setAttribute("aria-expanded", String(open));
      if (save) persist();
    }
    const isMobile = () => window.innerWidth < 1100;

    async function refresh() {
      try {
        const data = await adapter.list();
        folders = data.folders || [];
        convs = data.conversations || [];
      } catch (e) {
        toast?.(e.message);
      }
      render();
    }

    function upsert(meta) {
      const i = convs.findIndex((c) => c.id === meta.id);
      if (i >= 0) convs[i] = { ...convs[i], ...meta };
      else convs.unshift(meta);
      convs.sort((a, b) => (b.updatedAt || "").localeCompare(a.updatedAt || ""));
      render();
    }

    function when(iso) {
      if (!iso) return "";
      const d = new Date(iso);
      const now = new Date();
      const days = Math.floor((now - d) / 86400000);
      if (d.toDateString() === now.toDateString()) return d.toLocaleTimeString("es-ES", { hour: "2-digit", minute: "2-digit" });
      if (days < 7) return d.toLocaleDateString("es-ES", { weekday: "short" });
      return d.toLocaleDateString("es-ES", { day: "numeric", month: "short" });
    }

    function convRow(c) {
      const active = c.id === getActiveId();
      if (editing?.type === "conv" && editing.id === c.id) {
        return `<div class="sb-conv is-editing"><input class="sb-input" data-edit-conv="${esc(c.id)}" value="${esc(c.title)}" maxlength="120" aria-label="Nuevo nombre"></div>`;
      }
      const open = menu?.type === "conv" && menu.id === c.id;
      return `<div class="sb-conv${active ? " is-active" : ""}" draggable="true" data-conv="${esc(c.id)}">
        <button type="button" class="sb-conv-main" data-open-conv="${esc(c.id)}" title="${esc(c.title)}">
          <span class="sb-conv-t">${esc(c.title)}</span><span class="sb-conv-d">${esc(when(c.updatedAt))}</span>
        </button>
        <button type="button" class="sb-more${open ? " is-open" : ""}" data-menu-conv="${esc(c.id)}" aria-label="Opciones de la conversación" aria-expanded="${open}">⋯</button>
        ${open ? convMenu(c) : ""}
      </div>`;
    }
    function convMenu(c) {
      const del = confirmDelete === "conv:" + c.id;
      return `<div class="sb-menu" role="menu">
        <button type="button" role="menuitem" data-act="rename-conv" data-id="${esc(c.id)}">Cambiar nombre</button>
        <div class="sb-menu-label">Mover a</div>
        ${folders.map((f) => `<button type="button" role="menuitem" data-act="move" data-id="${esc(c.id)}" data-folder="${esc(f.id)}" ${c.folderId === f.id ? "disabled" : ""}>${esc(f.name)}</button>`).join("")}
        <button type="button" role="menuitem" data-act="move" data-id="${esc(c.id)}" data-folder="" ${!c.folderId ? "disabled" : ""}>Sin carpeta</button>
        <button type="button" role="menuitem" data-act="new-folder-move" data-id="${esc(c.id)}">+ Carpeta nueva…</button>
        <hr>
        <button type="button" role="menuitem" class="danger" data-act="delete-conv" data-id="${esc(c.id)}">${del ? "¿Seguro? Pulsa otra vez para eliminar" : "Eliminar"}</button>
      </div>`;
    }
    function folderBlock(f, items) {
      const isCol = collapsed.has(f.id) && !filterText();
      const open = menu?.type === "folder" && menu.id === f.id;
      const del = confirmDelete === "folder:" + f.id;
      const head = editing?.type === "folder" && editing.id === f.id
        ? `<div class="sb-folder-h is-editing"><input class="sb-input" data-edit-folder="${esc(f.id)}" value="${esc(f.name)}" maxlength="60" aria-label="Nombre de la carpeta"></div>`
        : `<div class="sb-folder-h" data-drop="${esc(f.id)}">
            <button type="button" class="sb-folder-toggle" data-toggle-folder="${esc(f.id)}" aria-expanded="${!isCol}">
              <span class="sb-caret">${isCol ? "▸" : "▾"}</span><span class="sb-folder-n">${esc(f.name)}</span><span class="sb-count">${items.length}</span>
            </button>
            <button type="button" class="sb-more${open ? " is-open" : ""}" data-menu-folder="${esc(f.id)}" aria-label="Opciones de la carpeta">⋯</button>
            ${open ? `<div class="sb-menu" role="menu">
              <button type="button" role="menuitem" data-act="new-in-folder" data-id="${esc(f.id)}">Nueva conversación aquí</button>
              <button type="button" role="menuitem" data-act="rename-folder" data-id="${esc(f.id)}">Cambiar nombre</button>
              <hr>
              <button type="button" role="menuitem" class="danger" data-act="delete-folder" data-id="${esc(f.id)}">${del ? "¿Seguro? Las conversaciones no se borran" : "Eliminar carpeta"}</button>
            </div>` : ""}
          </div>`;
      return `<section class="sb-folder">${head}${isCol ? "" : `<div class="sb-folder-items">${items.length ? items.map(convRow).join("") : '<p class="sb-empty">Arrastra aquí conversaciones o usa ⋯ › Mover a</p>'}</div>`}</section>`;
    }
    const filterText = () => els.filter.value.trim().toLowerCase();

    function render() {
      const q = filterText();
      const vis = q ? convs.filter((c) => (c.title || "").toLowerCase().includes(q)) : convs;
      const byFolder = new Map(folders.map((f) => [f.id, []]));
      const loose = [];
      for (const c of vis) (c.folderId && byFolder.has(c.folderId) ? byFolder.get(c.folderId) : loose).push(c);
      const newFolder = editing?.type === "newFolder"
        ? `<div class="sb-folder-h is-editing"><input class="sb-input" data-new-folder value="" placeholder="Nombre de la carpeta" maxlength="60" aria-label="Nombre de la carpeta"></div>`
        : "";
      els.list.innerHTML = `
        <div class="sb-head"><span>Carpetas</span><button type="button" class="sb-add" data-act="add-folder" title="Nueva carpeta" aria-label="Nueva carpeta"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 6v12M6 12h12" /></svg></button></div>
        ${newFolder}
        ${folders.length ? folders.map((f) => folderBlock(f, byFolder.get(f.id))).join("") : newFolder ? "" : '<p class="sb-empty">Crea carpetas para ordenar tus conversaciones.</p>'}
        <div class="sb-head" data-drop=""><span>${q ? "Resultados" : "Conversaciones"}</span></div>
        <div class="sb-loose" data-drop="">${loose.length ? loose.map(convRow).join("") : `<p class="sb-empty">${q ? "Nada coincide con la búsqueda." : convs.length ? "Todas están en carpetas." : "Aún no hay conversaciones guardadas."}</p>`}</div>`;
      const input = els.list.querySelector(".sb-input");
      if (input) { input.focus(); input.select(); }
    }

    // ------------------------------------------------------------ acciones
    async function act(fn) {
      try { await fn(); } catch (e) { toast?.(e.message); }
    }
    function closeMenus() { menu = null; confirmDelete = null; }

    els.list.addEventListener("click", (e) => {
      const b = e.target.closest("button");
      if (!b) return;
      const d = b.dataset;
      if (d.openConv) { closeMenus(); onOpen(d.openConv); if (isMobile()) setOpen(false); render(); return; }
      if (d.toggleFolder) { collapsed.has(d.toggleFolder) ? collapsed.delete(d.toggleFolder) : collapsed.add(d.toggleFolder); persist(); render(); return; }
      if (d.menuConv) { const same = menu?.type === "conv" && menu.id === d.menuConv; closeMenus(); menu = same ? null : { type: "conv", id: d.menuConv }; render(); return; }
      if (d.menuFolder) { const same = menu?.type === "folder" && menu.id === d.menuFolder; closeMenus(); menu = same ? null : { type: "folder", id: d.menuFolder }; render(); return; }
      switch (d.act) {
        case "add-folder": closeMenus(); editing = { type: "newFolder" }; render(); break;
        case "rename-conv": closeMenus(); editing = { type: "conv", id: d.id }; render(); break;
        case "rename-folder": closeMenus(); editing = { type: "folder", id: d.id }; render(); break;
        case "move":
          closeMenus();
          act(async () => { upsert(await adapter.patch(d.id, { folderId: d.folder || null })); });
          break;
        case "new-folder-move": closeMenus(); editing = { type: "newFolder", moveId: d.id }; render(); break;
        case "new-in-folder": closeMenus(); onNew(d.id); if (isMobile()) setOpen(false); render(); break;
        case "delete-conv":
          if (confirmDelete !== "conv:" + d.id) { confirmDelete = "conv:" + d.id; render(); break; }
          closeMenus();
          act(async () => { await adapter.remove(d.id); convs = convs.filter((c) => c.id !== d.id); onDeleted?.(d.id); render(); });
          break;
        case "delete-folder":
          if (confirmDelete !== "folder:" + d.id) { confirmDelete = "folder:" + d.id; render(); break; }
          closeMenus();
          act(async () => {
            await adapter.deleteFolder(d.id);
            folders = folders.filter((f) => f.id !== d.id);
            convs.forEach((c) => { if (c.folderId === d.id) c.folderId = null; });
            render();
          });
          break;
      }
    });

    // Edición en línea: Intro guarda, Esc cancela, salir del campo guarda
    const commit = (input) => {
      const val = input.value.trim();
      const ed = editing;
      editing = null;
      if (!ed) return;
      if (ed.type === "newFolder") {
        if (!val) return render();
        act(async () => {
          const f = await adapter.createFolder(val);
          folders.push(f);
          if (ed.moveId) upsert(await adapter.patch(ed.moveId, { folderId: f.id }));
          render();
        });
      } else if (ed.type === "folder") {
        const f = folders.find((x) => x.id === ed.id);
        if (!val || !f || val === f.name) return render();
        act(async () => { await adapter.renameFolder(ed.id, val); f.name = val; render(); });
      } else if (ed.type === "conv") {
        const c = convs.find((x) => x.id === ed.id);
        if (!val || !c || val === c.title) return render();
        act(async () => { upsert(await adapter.patch(ed.id, { title: val })); onRenamed?.(ed.id, val); });
      }
      render();
    };
    let onRenamed = null;
    els.list.addEventListener("keydown", (e) => {
      if (!e.target.classList.contains("sb-input")) return;
      if (e.key === "Enter") { e.preventDefault(); commit(e.target); }
      if (e.key === "Escape") { editing = null; render(); }
    });
    els.list.addEventListener("focusout", (e) => {
      if (e.target.classList.contains("sb-input") && editing) commit(e.target);
    });

    // Arrastrar conversaciones a carpetas
    els.list.addEventListener("dragstart", (e) => {
      const row = e.target.closest("[data-conv]");
      if (!row) return;
      dragId = row.dataset.conv;
      e.dataTransfer.effectAllowed = "move";
      e.dataTransfer.setData("text/plain", dragId);
      row.classList.add("is-dragging");
    });
    els.list.addEventListener("dragend", () => { dragId = null; els.list.querySelectorAll(".is-drop, .is-dragging").forEach((x) => x.classList.remove("is-drop", "is-dragging")); });
    els.list.addEventListener("dragover", (e) => {
      const t = e.target.closest("[data-drop]");
      if (!t || !dragId) return;
      e.preventDefault();
      els.list.querySelectorAll(".is-drop").forEach((x) => x !== t && x.classList.remove("is-drop"));
      t.classList.add("is-drop");
    });
    els.list.addEventListener("drop", (e) => {
      const t = e.target.closest("[data-drop]");
      if (!t || !dragId) return;
      e.preventDefault();
      const id = dragId;
      const folderId = t.dataset.drop || null;
      dragId = null;
      const c = convs.find((x) => x.id === id);
      if (c && (c.folderId || null) === folderId) return render();
      act(async () => { upsert(await adapter.patch(id, { folderId })); });
    });

    document.addEventListener("click", (e) => {
      if (menu && !e.target.closest(".sb-menu, .sb-more")) { closeMenus(); render(); }
    });
    els.filter.addEventListener("input", render);
    els.newBtn.onclick = () => { onNew(null); if (isMobile()) setOpen(false); render(); };
    if (els.toggle) els.toggle.onclick = () => setOpen(!isOpen());
    if (els.backdrop) els.backdrop.onclick = () => setOpen(false);

    return {
      refresh,
      upsert,
      render,
      remove: (id) => { convs = convs.filter((c) => c.id !== id); render(); },
      folderName: (id) => folders.find((f) => f.id === id)?.name || "",
      set onRenamed(fn) { onRenamed = fn; },
      close: () => setOpen(false),
    };
  }

  window.RegLibrary = { create, serverAdapter, browserAdapter, newId };
})();
