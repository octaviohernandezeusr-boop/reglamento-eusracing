// Explorador del reglamento: índice en árbol, lectura por artículo completo, búsqueda,
// historial atrás/adelante, recientes y acciones por apartado (preguntar, copiar).
(function () {
  "use strict";

  const SECTION_ES = {
    A: "Reglamento administrativo",
    B: "Reglamento técnico general",
    C: "Reglamento técnico eFuel",
    D: "Reglamento técnico Electric",
    E: "Verificaciones técnicas",
    F: "Estructura de la competición (MS1)",
    G: "Reglamento deportivo (MS2)",
    H: "Evento final",
    I: "Glosario de modificaciones",
    J: "Anexos",
  };

  const esc = (s) =>
    String(s ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  const titleCase = (s) => (s ? s.charAt(0) + s.slice(1).toLowerCase() : "");

  const store = {
    get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* sin almacenamiento */ } },
  };

  // ------------------------------------------------------------------ búsqueda BM25
  const STOP = new Set("the a an of to and or in on for with by be is are must shall may at as from that this which any all its it their not no el la los las de del que y en se por para con un una al lo su sus es este esta deberá deberán podrá será".split(" "));
  const tok = (s) =>
    s.toLowerCase().normalize("NFKD").replace(/[̀-ͯ]/g, "").split(/[^a-z0-9.]+/)
      .map((w) => w.replace(/^\.+|\.+$/g, "")).filter((w) => w.length > 1 && !STOP.has(w));
  const stem = (w) => w.replace(/(ies|es|s)$/, (m) => (m === "ies" ? "y" : "")).replace(/(ing|ed)$/, "");

  function buildIndex(nodes, titleOf) {
    const docs = nodes.filter((n) => n.text || n.kind === "subsection").map((n) => {
      const words = tok(`${n.title || ""} ${n.subsection ? titleOf(n.subsection) : ""} ${n.text || ""}`).map(stem);
      const tf = new Map();
      for (const w of words) tf.set(w, (tf.get(w) || 0) + 1);
      return { n, tf, len: words.length };
    });
    const df = new Map();
    for (const d of docs) for (const w of d.tf.keys()) df.set(w, (df.get(w) || 0) + 1);
    const avg = docs.reduce((a, d) => a + d.len, 0) / Math.max(1, docs.length);
    return function rank(query, section) {
      const q = [...new Set(tok(query).map(stem))];
      const N = docs.length;
      const out = [];
      for (const d of docs) {
        if (section && d.n.section !== section) continue;
        let s = 0;
        for (const w of q) {
          const f = d.tf.get(w);
          if (!f) continue;
          const idf = Math.log(1 + (N - df.get(w) + 0.5) / (df.get(w) + 0.5));
          s += idf * ((f * 2.2) / (f + 1.2 * (0.25 + 0.75 * (d.len / avg))));
        }
        if (s > 0) out.push([s, d.n]);
      }
      return out.sort((a, b) => b[0] - a[0]);
    };
  }

  // ------------------------------------------------------------------ explorador
  function create({ nodes, sections, revision, onAsk, lang: initialLang = "es", storageKey = "eus-reg-explorer-v1" }) {
    let lang = initialLang;
    const $ = (s, el = document) => el.querySelector(s);
    const els = {
      drawer: $("#drawer"),
      title: $("#drawer-title"),
      back: $("#x-back"),
      fwd: $("#x-fwd"),
      home: $("#x-home"),
      tocBtn: $("#x-toc"),
      wide: $("#x-wide"),
      close: $("#drawer-close"),
      search: $("#search"),
      tree: $("#x-tree"),
      body: $("#drawer-body"),
    };

    // Índices
    const byId = new Map(nodes.map((n) => [n.id, n]));
    // Texto y títulos en el idioma elegido (con el inglés como respaldo)
    const T = (n) => (lang === "es" && n?.es?.title) || n?.title || "";
    const X = (n) => (lang === "es" && n?.es?.text) || n?.text || "";
    const untranslated = (n) => lang === "es" && n?.text && !n?.es?.text;
    const nice = (n) => { const t = T(n); return t === t.toUpperCase() ? titleCase(t) : t; };
    const titleOf = (id) => T(byId.get(id));
    const articles = nodes.filter((n) => n.kind === "article" || n.kind === "annex");
    const articlesOf = (sec) => articles.filter((a) => a.section === sec);
    const subsOf = (artId) => nodes.filter((n) => n.kind === "subsection" && n.article === artId);
    const clausesOf = (subId) => nodes.filter((n) => n.kind === "clause" && n.subsection === subId);
    const sectionIds = Object.keys(sections);
    const indexes = {};
    const rank = (q, sec) => {
      if (!indexes[lang]) {
        const view = nodes.map((n) => ({ ...n, title: T(n), text: X(n) }));
        const r = buildIndex(view, (id) => titleOf(id));
        const back = new Map(view.map((v, i) => [v, nodes[i]]));
        indexes[lang] = (qq, ss) => r(qq, ss).map(([sc, v]) => [sc, back.get(v)]);
      }
      return indexes[lang](q, sec);
    };

    function articleIdOf(n) {
      if (!n) return null;
      if (n.kind === "article" || n.kind === "annex") return n.id;
      return n.article || null;
    }
    function pagesOf(artId) {
      const ps = nodes.filter((n) => n.id === artId || n.article === artId).map((n) => n.page).filter(Boolean);
      if (!ps.length) return "";
      const a = Math.min(...ps), b = Math.max(...ps);
      return a === b ? `pág. ${a}` : `págs. ${a}–${b}`;
    }

    // Estado
    const saved = store.get(storageKey, {});
    let history = [];
    let pos = -1;
    let recents = Array.isArray(saved.recents) ? saved.recents.filter((id) => byId.has(id)).slice(0, 8) : [];
    let wide = Boolean(saved.wide);
    let lastView = saved.last && (saved.last.type === "home" || byId.has(saved.last.id) || saved.last.type === "search") ? saved.last : null;
    const persist = () => store.set(storageKey, { recents, wide, last: history[pos]?.view || lastView });

    // ------------------------------------------------------------ abrir / cerrar
    function isOpen() { return els.drawer.classList.contains("open"); }
    function show() {
      els.drawer.classList.add("open");
      els.drawer.setAttribute("aria-hidden", "false");
      document.body.classList.add("drawer-open");
      applyWide();
    }
    function close() {
      els.drawer.classList.remove("open", "toc-open");
      els.drawer.setAttribute("aria-hidden", "true");
      document.body.classList.remove("drawer-open", "drawer-wide");
    }
    function applyWide() {
      els.drawer.classList.toggle("wide", wide);
      document.body.classList.toggle("drawer-wide", wide && isOpen());
      els.wide.setAttribute("aria-pressed", String(wide));
      els.wide.title = wide ? "Reducir panel" : "Ampliar panel";
    }
    function toggle() {
      if (isOpen()) return close();
      show();
      if (pos < 0) navigate(lastView || { type: "home" });
    }

    // ------------------------------------------------------------ historial
    function navigate(view, { replace = false } = {}) {
      if (pos >= 0) history[pos].scroll = els.body.scrollTop;
      if (replace && pos >= 0) history[pos] = { view };
      else {
        history = history.slice(0, pos + 1);
        history.push({ view });
        pos = history.length - 1;
        if (history.length > 80) { history.shift(); pos--; }
      }
      render(history[pos], false);
    }
    function go(delta) {
      const next = pos + delta;
      if (next < 0 || next >= history.length) return;
      history[pos].scroll = els.body.scrollTop;
      pos = next;
      render(history[pos], true);
    }

    // ------------------------------------------------------------ render
    function render(entry, restoring) {
      const v = entry.view;
      show();
      els.drawer.classList.remove("toc-open");
      els.back.disabled = pos <= 0;
      els.fwd.disabled = pos >= history.length - 1;
      if (v.type === "home") renderHome();
      else if (v.type === "search") renderSearch(v.q);
      else renderArticle(v);
      renderTree(v);
      if (v.type !== "search" && document.activeElement !== els.search) els.search.value = "";
      lastView = v;
      persist();
      if (restoring && entry.scroll != null) {
        els.body.scrollTop = entry.scroll;
      } else if (v.type === "article" && v.focus && v.focus !== v.id) {
        const target = findEl(v.focus);
        if (target) {
          requestAnimationFrame(() => {
            target.scrollIntoView({ block: v.focusKind === "subsection" ? "start" : "center" });
            target.classList.add("flash");
          });
        } else els.body.scrollTop = 0;
      } else {
        els.body.scrollTop = 0;
      }
      spy();
    }

    function findEl(id) {
      for (const el of els.body.querySelectorAll("[data-id]")) if (el.dataset.id === id) return el;
      return null;
    }

    function crumbs(parts) {
      return `<nav class="x-crumbs" aria-label="Ruta">${parts
        .map((p, i) => (i < parts.length - 1 && p.open ? `<button type="button" class="x-crumb" data-nav='${esc(JSON.stringify(p.open))}'>${esc(p.label)}</button>` : `<span>${esc(p.label)}</span>`))
        .join('<span class="x-sep">›</span>')}</nav>`;
    }

    function renderHome() {
      els.title.textContent = "Índice";
      const rec = recents.length
        ? `<div class="x-recents"><div class="x-label">Visto recientemente</div><div class="x-chips">${recents
            .map((id) => { const n = byId.get(id); return `<button type="button" class="x-chip" data-open="${esc(id)}"><b>${esc(id)}</b> ${esc(shortTitle(n))}</button>`; })
            .join("")}</div></div>`
        : "";
      els.body.innerHTML = `
        <div class="x-home">
          <p class="x-note">Reglamento MS2627 ${esc(revision || "")}</p>
          ${rec}
          <div class="x-sections">${sectionIds
            .map((s) => {
              const arts = articlesOf(s);
              return `<section class="x-sec">
                <header class="x-sec-h"><span class="x-letter">${s}</span><div><strong>${esc(SECTION_ES[s] || titleCase(sections[s]))}</strong><small>${esc(lang === "es" ? "" : titleCase(sections[s]))}</small></div></header>
                ${arts.length ? `<div class="x-arts">${arts
                  .map((a) => `<button type="button" class="x-art" data-open="${esc(a.id)}"><span class="x-id">${esc(a.id)}</span><span class="x-art-t">${esc(nice(a))}</span><span class="x-page">${a.page ? a.page : ""}</span></button>`)
                  .join("")}</div>` : '<p class="x-empty">Sin contenido en esta versión.</p>'}
              </section>`;
            })
            .join("")}</div>
        </div>`;
    }

    function shortTitle(n) {
      if (!n) return "";
      if (n.kind === "clause") return titleOf(n.subsection) || nice(byId.get(n.article));
      return nice(n);
    }

    function formatText(text, re) {
      let out = "";
      let inList = false;
      const hl = (s) => (re ? esc(s).replace(re, "<mark>$1</mark>") : esc(s));
      for (const l of text.split("\n")) {
        const li = l.match(/^[-•]\s+(.*)/);
        if (li) {
          if (!inList) { out += "<ul>"; inList = true; }
          out += `<li>${hl(li[1])}</li>`;
        } else {
          if (inList) { out += "</ul>"; inList = false; }
          out += `<p>${hl(l)}</p>`;
        }
      }
      return inList ? out + "</ul>" : out;
    }

    function termsRe(q) {
      const t = q ? tok(q).filter((w) => w.length > 2) : [];
      return t.length ? new RegExp(`\\b(${t.map((w) => w.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).join("|")})\\w*`, "gi") : null;
    }

    function clauseHtml(n, re) {
      return `<div class="x-clause" data-id="${esc(n.id)}">
        <div class="x-clause-top">
          <span class="x-id">${esc(n.id)}</span>
          <span class="x-actions">
            <button type="button" class="x-act" data-ask="${esc(n.id)}" title="Preguntar a la IA sobre este apartado">Preguntar</button>
            <button type="button" class="x-act" data-copy="${esc(n.id)}" title="Copiar número y texto">Copiar</button>
          </span>
        </div>
        <div class="x-text">${formatText(X(n), re)}</div>
        ${untranslated(n) ? '<p class="x-lang-note">Sin traducción fiable: se muestra el original en inglés.</p>' : ""}
        ${lang === "es" && n.es?.text ? `<details class="x-orig"><summary>Original en inglés</summary>${formatText(n.text, null)}</details>` : ""}
        ${n.numberingNote ? `<p class="x-warn">Nota: ${esc(n.numberingNote)}</p>` : ""}
      </div>`;
    }

    function renderArticle(v) {
      const n = byId.get(v.focus || v.id);
      const artId = articleIdOf(byId.get(v.id)) || v.id;
      const art = byId.get(artId);
      if (!art) {
        els.title.textContent = v.focus || v.id;
        els.body.innerHTML = `<div class="x-missing"><p>El apartado <strong>${esc(v.focus || v.id)}</strong> no existe en el reglamento. Puede ser un error de la IA: compruébalo en el PDF oficial.</p><button type="button" class="x-btn" data-nav='{"type":"home"}'>Ir al índice</button></div>`;
        return;
      }
      addRecent(n && n.kind !== "section" ? n.id : art.id);
      const re = termsRe(v.q);
      const subs = subsOf(art.id);
      const i = articles.findIndex((a) => a.id === art.id);
      const prev = articles[i - 1], next = articles[i + 1];
      els.title.textContent = `${art.id} · ${nice(art)}`;
      els.body.innerHTML = `
        <article class="x-article">
          ${crumbs([
            { label: "Índice", open: { type: "home" } },
            { label: `Sección ${art.section} · ${SECTION_ES[art.section] || ""}`, open: { type: "home", section: art.section } },
            { label: art.id },
          ])}
          <header class="x-art-head">
            <h2><span class="x-id">${esc(art.id)}</span> ${esc(nice(art))}</h2>
            <div class="x-meta">${esc(pagesOf(art.id))}${subs.length ? ` · ${subs.length} subapartados` : ""}</div>
          </header>
          ${subs.length > 1 ? `<div class="x-jump" role="navigation" aria-label="Subapartados">${subs
            .map((s) => `<button type="button" class="x-jump-b" data-jump="${esc(s.id)}">${esc(s.id.split(".").pop())}. ${esc(T(s))}</button>`)
            .join("")}</div>` : ""}
          ${X(art) ? `<div class="x-intro">${formatText(X(art), re)}</div>` : ""}
          ${subs
            .map((s) => `<section class="x-sub" data-id="${esc(s.id)}" data-sub="${esc(s.id)}">
              <h3 class="x-sub-h"><span class="x-id">${esc(s.id)}</span> <span>${esc(T(s))}</span>${s.page ? `<span class="x-page">pág. ${s.page}</span>` : ""}</h3>
              ${X(s) ? `<div class="x-intro">${formatText(X(s), re)}</div>` : ""}
              ${clausesOf(s.id).map((c) => clauseHtml(c, re)).join("")}
            </section>`)
            .join("")}
          <footer class="x-pager">
            ${prev ? `<button type="button" class="x-pg" data-open="${esc(prev.id)}"><small>← Anterior</small><span>${esc(prev.id)} · ${esc(nice(prev))}</span></button>` : "<span></span>"}
            ${next ? `<button type="button" class="x-pg x-pg-next" data-open="${esc(next.id)}"><small>Siguiente →</small><span>${esc(next.id)} · ${esc(nice(next))}</span></button>` : "<span></span>"}
          </footer>
        </article>`;
    }

    function renderSearch(q) {
      els.title.textContent = "Búsqueda";
      const hits = rank(q).slice(0, 80).map(([, n]) => n);
      const re = termsRe(q);
      if (!hits.length) {
        els.body.innerHTML = `<div class="x-missing"><p>Sin resultados para «${esc(q)}». ${lang === "es" ? "Prueba con otras palabras (p. ej. <em>freno</em>, <em>batería</em>, <em>casco</em>)" : "Prueba con palabras como <em>brake</em>, <em>battery</em> o <em>helmet</em>"} o pregúntalo en el chat.</p></div>`;
        return;
      }
      // Agrupar por artículo, manteniendo el orden de relevancia del primer resultado
      const groups = new Map();
      for (const n of hits) {
        const a = articleIdOf(n) || n.id;
        if (!groups.has(a)) groups.set(a, []);
        groups.get(a).push(n);
      }
      els.body.innerHTML = `<div class="x-results">
        <p class="x-note">${hits.length}${hits.length === 80 ? "+" : ""} resultados para «${esc(q)}» en ${groups.size} artículos</p>
        ${[...groups]
          .map(([a, list]) => {
            const art = byId.get(a);
            return `<section class="x-group">
              <button type="button" class="x-group-h" data-open="${esc(a)}"><span class="x-id">${esc(a)}</span> ${esc(art ? nice(art) : "")}</button>
              ${list
                .map((n) => {
                  const t = X(n) || T(n);
                  const first = re ? t.search(re) : 0;
                  const start = Math.max(0, first - 70);
                  const snip = (start ? "…" : "") + t.slice(start, start + 240) + (t.length > start + 240 ? "…" : "");
                  return `<button type="button" class="x-hit" data-open="${esc(n.id)}" data-q="${esc(q)}">
                    <span class="x-hit-top"><span class="x-id">${esc(n.id)}</span><span class="x-hit-t">${esc(shortTitle(n))}</span></span>
                    <span class="x-hit-s">${re ? esc(snip).replace(re, "<mark>$1</mark>") : esc(snip)}</span>
                  </button>`;
                })
                .join("")}
            </section>`;
          })
          .join("")}
      </div>`;
    }

    function renderTree(v) {
      const curArt = v.type === "article" ? articleIdOf(byId.get(v.id)) : null;
      const curSec = curArt ? byId.get(curArt)?.section : v.section || null;
      els.tree.innerHTML = `<button type="button" class="x-tree-home${v.type === "home" ? " is-cur" : ""}" data-nav='{"type":"home"}'>Índice general</button>` +
        sectionIds
          .map((s) => {
            const arts = articlesOf(s);
            if (!arts.length) return "";
            return `<details class="x-tsec" ${s === curSec ? "open" : ""}>
              <summary><span class="x-letter sm">${s}</span> ${esc(SECTION_ES[s] || titleCase(sections[s]))}</summary>
              ${arts
                .map((a) => {
                  const cur = a.id === curArt;
                  const subs = cur ? subsOf(a.id) : [];
                  return `<button type="button" class="x-tart${cur ? " is-cur" : ""}" data-open="${esc(a.id)}"><span class="x-id">${esc(a.id)}</span> ${esc(nice(a))}</button>
                    ${subs.length ? `<div class="x-tsubs">${subs.map((sb) => `<button type="button" class="x-tsub" data-jump="${esc(sb.id)}" data-tsub="${esc(sb.id)}">${esc(sb.id)} ${esc(T(sb))}</button>`).join("")}</div>` : ""}`;
                })
                .join("")}
            </details>`;
          })
          .join("");
      const cur = els.tree.querySelector(".x-tart.is-cur");
      if (cur && (cur.offsetTop < els.tree.scrollTop || cur.offsetTop > els.tree.scrollTop + els.tree.clientHeight - 60)) {
        els.tree.scrollTop = cur.offsetTop - 80;
      }
      if (v.type === "home" && v.section) {
        requestAnimationFrame(() => {
          const secs = els.body.querySelectorAll(".x-sec");
          const idx = sectionIds.indexOf(v.section);
          if (secs[idx]) secs[idx].scrollIntoView({ block: "start" });
        });
      }
    }

    // Resaltar en el árbol y en la barra de saltos el subapartado que se está leyendo
    let spyRaf = 0;
    function spy() {
      if (spyRaf) return;
      spyRaf = requestAnimationFrame(() => {
        spyRaf = 0;
        const subs = els.body.querySelectorAll(".x-sub");
        if (!subs.length) return;
        const top = els.body.getBoundingClientRect().top + 80;
        let cur = subs[0].dataset.sub;
        for (const s of subs) { if (s.getBoundingClientRect().top <= top) cur = s.dataset.sub; else break; }
        els.tree.querySelectorAll(".x-tsub").forEach((b) => b.classList.toggle("is-cur", b.dataset.tsub === cur));
        els.body.querySelectorAll(".x-jump-b").forEach((b) => {
          const on = b.dataset.jump === cur;
          if (on && !b.classList.contains("is-cur")) {
            // Desplazar solo la barra (scrollIntoView cortaría el desplazamiento suave del texto)
            const bar = b.parentElement;
            if (b.offsetLeft < bar.scrollLeft || b.offsetLeft + b.offsetWidth > bar.scrollLeft + bar.clientWidth) {
              bar.scrollLeft = b.offsetLeft - bar.offsetLeft - 12;
            }
          }
          b.classList.toggle("is-cur", on);
        });
      });
    }
    els.body.addEventListener("scroll", spy, { passive: true });

    function addRecent(id) {
      recents = [id, ...recents.filter((r) => r !== id)].slice(0, 8);
    }

    // ------------------------------------------------------------ API pública
    function open(id, extra = {}) {
      const n = byId.get(id);
      const view = { type: "article", id: (n && articleIdOf(n)) || id, focus: id, focusKind: n?.kind, ...extra };
      if (n && n.kind === "section") return navigate({ type: "home", section: n.id });
      navigate(view);
    }
    function home() { navigate({ type: "home" }); }

    const ID_ONLY = /^\s*(?:art(?:ículo|\.)?\s*)?([A-Ja-j](?:\.\d+){1,4}(?: \(\d\))?|(?:annex|anexo)\s*\d+)\s*$/i;
    function searchFor(q, replace) {
      q = q.trim();
      if (!q) return;
      const m = q.match(ID_ONLY);
      if (m) {
        let id = m[1].replace(/^(annex|anexo)\s*/i, "Annex ");
        id = id.charAt(0).toUpperCase() + id.slice(1);
        if (byId.has(id)) return open(id);
      }
      navigate({ type: "search", q }, { replace: replace && history[pos]?.view.type === "search" });
    }

    // ------------------------------------------------------------ eventos
    els.back.onclick = () => go(-1);
    els.fwd.onclick = () => go(1);
    els.home.onclick = () => home();
    els.close.onclick = close;
    els.wide.onclick = () => { wide = !wide; applyWide(); persist(); };
    els.tocBtn.onclick = () => els.drawer.classList.toggle("toc-open");

    let t;
    els.search.addEventListener("input", () => {
      clearTimeout(t);
      const q = els.search.value;
      if (!q.trim()) return;
      t = setTimeout(() => searchFor(q, true), 280);
    });
    els.search.addEventListener("keydown", (e) => {
      if (e.key === "Enter") { clearTimeout(t); searchFor(els.search.value, true); }
      if (e.key === "Escape") { els.search.value = ""; els.search.blur(); }
    });

    els.drawer.addEventListener("click", async (e) => {
      const b = e.target.closest("button");
      if (!b || !els.drawer.contains(b)) return;
      if (b.dataset.nav) return navigate(JSON.parse(b.dataset.nav));
      if (b.dataset.jump) {
        const cur = history[pos]?.view;
        const target = findEl(b.dataset.jump);
        els.drawer.classList.remove("toc-open");
        if (target && cur?.type === "article") {
          target.scrollIntoView({ block: "start", behavior: matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth" });
          return;
        }
        return open(b.dataset.jump);
      }
      if (b.dataset.open) return open(b.dataset.open, b.dataset.q ? { q: b.dataset.q } : {});
      if (b.dataset.ask) { onAsk?.(b.dataset.ask); if (window.innerWidth < 1100 || wide) close(); return; }
      if (b.dataset.copy) {
        const n = byId.get(b.dataset.copy);
        const text = `${n.id}${n.page ? ` (pág. ${n.page})` : ""}: ${X(n)}`;
        try { await navigator.clipboard.writeText(text); b.textContent = "Copiado"; } catch { b.textContent = "No se pudo"; }
        setTimeout(() => (b.textContent = "Copiar"), 1400);
      }
    });

    document.addEventListener("keydown", (e) => {
      if (!isOpen()) return;
      const typing = /INPUT|TEXTAREA/.test(document.activeElement?.tagName || "");
      if (e.altKey && e.key === "ArrowLeft") { e.preventDefault(); go(-1); }
      else if (e.altKey && e.key === "ArrowRight") { e.preventDefault(); go(1); }
      else if (e.key === "/" && !typing) { e.preventDefault(); els.search.focus(); els.search.select(); }
      else if (e.key === "Escape" && !typing) {
        if (els.drawer.classList.contains("toc-open")) els.drawer.classList.remove("toc-open");
        else close();
      }
    });

    applyWide();
    function setLang(l) {
      lang = l === "en" ? "en" : "es";
      els.search.placeholder = lang === "es" ? "Buscar o ir a un apartado" : "Search or go to a clause";
      if (pos >= 0 && isOpen()) render(history[pos], true);
    }
    setLang(lang);
    return { open, home, toggle, close, isOpen, rank, byId, setLang };
  }

  window.RegExplorer = { create, buildIndex };
})();
