#!/usr/bin/env python3
"""
Convierte el texto extraído del reglamento MotoStudent (versión EN) en un JSON
de apartados numerados, listo para que el servidor lo use como contexto.

Uso:
    python3 scripts/parse_regulations.py scripts/MS2627_Regulations_EN.txt data/regulations.json

Si sale una nueva revisión del reglamento: extrae el texto del PDF
(p. ej. `pdftotext -layout no`, o `pdftotext archivo.pdf salida.txt`) y vuelve a ejecutar.
"""
import json
import re
import sys

PAGE_RE = re.compile(r"^Rev\.\s*\d+\s*[–-]\s*\d+/\d+\s+(\d+)\s+IX MotoStudent\s*$")
SECTION_RE = re.compile(r"^SECTION ([A-J])\s*$")
TOC_SECTION_RE = re.compile(r"^SECTION ([A-J]):\s*(.+?)\s*\.{3,}\s*\d+\s*$")
ARTICLE_RE = re.compile(r"^ARTICLE (\d+):\s*(.+?)\s*$")
ANNEX_RE = re.compile(r"^ANNEX (\d+):\s*(.+?)\s*$")
CLAUSE_RE = re.compile(r"^([A-J])\.(\d+)((?:\.\d+)+)\.?\s+(.*)$")


def clean_title(t):
    t = re.sub(r"\s{2,}", " ", t).strip()
    return t


def id_key(cid):
    parts = cid.split(".")
    return [parts[0]] + [int(p) for p in parts[1:]]


def main(src, dst):
    lines = open(src, encoding="utf-8").read().splitlines()

    # 1) Títulos de sección desde el índice (los del cuerpo salen con espacios rotos).
    section_titles = {}
    for ln in lines[:200]:
        m = TOC_SECTION_RE.match(ln.strip())
        if m:
            section_titles[m.group(1)] = clean_title(m.group(2))

    # 2) El cuerpo empieza en la primera cabecera "SECTION A" suelta (tras el índice).
    start = next(i for i, ln in enumerate(lines) if SECTION_RE.match(ln.strip()))

    nodes = []          # lista de apartados
    page = None
    section = None
    article = None      # (num, title)
    subsection = None   # (id, title)
    current = None      # nodo al que se van añadiendo líneas

    def new_node(cid, kind, title, text):
        nonlocal current
        node = {
            "id": cid,
            "kind": kind,                     # section | article | subsection | clause | annex
            "section": section,
            "sectionTitle": section_titles.get(section, ""),
            "article": f"{section}.{article[0]}" if article and section != "J" else None,
            "articleTitle": article[1] if article else None,
            "subsection": subsection[0] if subsection else None,
            "subsectionTitle": subsection[1] if subsection else None,
            "title": title,
            "page": page,
            "lines": [text] if text else [],
        }
        nodes.append(node)
        current = node
        return node

    last_clause_key = None
    pending = None   # artículo recién abierto que aún no tiene apartados
    deferred = None  # artículo retrasado por una cabecera mal colocada
    for raw in lines[start:]:
        ln = raw.rstrip()
        s = ln.strip()
        if not s:
            continue
        m = PAGE_RE.match(s)
        if m:
            page = int(m.group(1))
            continue

        m = SECTION_RE.match(s)
        if m:
            section = m.group(1)
            article, subsection = None, None
            last_clause_key = None
            new_node(section, "section", section_titles.get(section, ""), "")
            continue
        # Líneas de título de sección que siguen a "SECTION X" (ya tenemos el título del índice)
        if current is not None and current["kind"] == "section" and not current["lines"] and \
                s.upper() == s and not ARTICLE_RE.match(s) and not ANNEX_RE.match(s):
            continue
        if s.startswith("SECTION ") and ":" in s and s.upper() == s:
            # cabecera duplicada tipo "SECTION A: ADMINISTRATI VE REG ULATIONS"
            continue

        m = ARTICLE_RE.match(s)
        if m and section and section != "J":
            deferred = None
            prev_state = (article, subsection, current)
            article = (int(m.group(1)), clean_title(m.group(2)))
            subsection = None
            pending = {"prev": prev_state, "node": new_node(f"{section}.{article[0]}", "article", article[1], ""),
                       "article": article}
            continue

        m = ANNEX_RE.match(s)
        if m and section == "J":
            article = (int(m.group(1)), clean_title(m.group(2)))
            subsection = None
            new_node(f"Annex {article[0]}", "annex", article[1], "")
            continue

        m = CLAUSE_RE.match(s)
        # El extractor de PDF a veces coloca la cabecera "ARTICLE N" antes de los últimos
        # apartados del artículo anterior: se devuelven a su sitio.
        if m and section and m.group(1) == section and pending and pending["prev"][0] and \
                int(m.group(2)) == pending["prev"][0][0] and article == pending["article"]:
            prev_article, prev_sub, prev_current = pending["prev"]
            node = pending["node"]
            prev_current["lines"].extend(node["lines"])
            node["lines"] = []
            nodes.remove(node)
            deferred = pending
            pending = None
            article, subsection, current = prev_article, prev_sub, prev_current
        if m and section and deferred and m.group(1) == section and \
                int(m.group(2)) == deferred["article"][0]:
            article = deferred["article"]
            subsection = None
            deferred["node"]["page"] = page
            nodes.append(deferred["node"])
            current = deferred["node"]
            deferred = None
        if m and section and m.group(1) == section and article and \
                int(m.group(2)) == article[0]:
            if pending and article == pending["article"]:
                pending = None
            cid = f"{m.group(1)}.{m.group(2)}{m.group(3)}"
            key = id_key(cid)
            depth = cid.count(".")
            parent = cid.rsplit(".", 1)[0]
            sub_key = id_key(subsection[0]) if subsection else None
            # Evita confundir una referencia al inicio de línea con un apartado nuevo,
            # tolerando las erratas de numeración del propio reglamento.
            if depth == 2:
                ok = sub_key is None or key > sub_key
            else:
                ok = True  # los apartados de 4 niveles son fiables (erratas incluidas)
            if ok:
                last_clause_key = key if last_clause_key is None else max(last_clause_key, key)
                rest = m.group(4).strip()
                if depth == 2:
                    subsection = (cid, clean_title(rest))
                    new_node(cid, "subsection", subsection[1], "")
                else:
                    node = new_node(cid, "clause", None, rest)
                    if subsection and parent != subsection[0]:
                        node["numberingNote"] = (
                            f"Numerado así en el reglamento, aunque está dentro de {subsection[0]}.")
                continue
            else:
                print("rechazado:", cid, "| último:", last_clause_key, "| sub:", subsection, file=sys.stderr)

        if current is None:
            continue
        current["lines"].append(s)

    # 3) Unir líneas en párrafos legibles.
    out = []
    for n in nodes:
        text = ""
        for l in n.pop("lines"):
            if not text:
                text = l
            elif l.startswith("- ") and text.count("(") > text.count(")"):
                text += " " + l  # "(also the Low Voltage System - LVS)": no es una lista
            elif l.startswith("- ") or l.startswith("• ") or re.match(r"^[a-z]\)\s", l) \
                    or text.endswith(":") or text.endswith("."):
                text += "\n" + l
            else:
                text += " " + l
        n["text"] = re.sub(r"[ \t]{2,}", " ", text).strip()
        out.append(n)

    # Nodos vacíos de tipo section/article/subsection se conservan: sirven de índice.
    # Ids repetidos por erratas: se renombra el que está fuera de sitio (o, si no, el segundo)
    first = {}
    for n in out:
        cid = n["id"]
        if cid not in first:
            first[cid] = n
            continue
        print("AVISO: id duplicado en el reglamento:", cid, file=sys.stderr)
        prev = first[cid]
        victim = prev if prev.get("numberingNote") and not n.get("numberingNote") else n
        victim["id"] = f"{cid} (2)"
        victim["numberingNote"] = (victim.get("numberingNote", "") +
                                   f" El número {cid} aparece dos veces en el reglamento.").strip()
        if victim is prev:
            first[cid] = n

    doc = {
        "title": "MS2627 IX MotoStudent International Competition — Rules & Regulations",
        "revision": "Rev. 01 – 04/2026 (V1.0)",
        "language": "en",
        "sections": section_titles,
        "nodes": out,
    }
    json.dump(doc, open(dst, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    kinds = {}
    for n in out:
        kinds[n["kind"]] = kinds.get(n["kind"], 0) + 1
    print(f"{len(out)} nodos -> {dst}  {kinds}")


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
