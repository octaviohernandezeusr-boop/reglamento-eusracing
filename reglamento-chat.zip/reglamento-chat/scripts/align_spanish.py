#!/usr/bin/env python3
"""
Alinea la traducción oficial al español (PDF bilingüe) con los apartados numerados.

En el PDF bilingüe cada página tiene primero el texto en inglés (con números de apartado) y
después la traducción al español (sin números). Por cada página se trocea el texto en inglés
en unidades (títulos y apartados) y se reparte el español entre esas unidades con programación
dinámica, usando la proporción de longitudes (método de Gale-Church) y los finales de frase.

Uso:
    python3 scripts/align_spanish.py scripts/MS2627_Regulations_ES_bilingue.txt data/regulations.json data/regulations.es.json
"""
import json
import math
import re
import sys
from collections import defaultdict

PAGE_RE = re.compile(r"^Rev\.\s*\d+\s*[–-]\s*\d+/\d+\s+(\d+)\s+IX MotoStudent\s*$")
CLAUSE_RE = re.compile(r"^([A-J])\.(\d+)((?:\.\d+)+)\.?\s+(.*)$")
ARTICLE_RE = re.compile(r"^ARTICLE (\d+):\s*(.+?)\s*$")
ANNEX_RE = re.compile(r"^ANNEX (\d+):\s*(.+?)\s*$")
SECTION_RE = re.compile(r"^SECTION ([A-J])\s*$")
TOC_ES_RE = re.compile(r"^(SECCIÓN ([A-J])|ARTÍCULO (\d+)|ANEXO (\d+)):\s*(.+?)\s*\.{3,}\s*\d*\s*$")

EN_WORDS = set("the of and to must be is are shall with for in by or on this that which will may any all from as at an".split())
ES_WORDS = set("el la los las de del que y en se por para con un una deberá deberán será podrá al lo su sus no es este esta".split())


def lang_score(line):
    ws = re.findall(r"[a-záéíóúñü]+", line.lower())
    en = sum(w in EN_WORDS for w in ws)
    es = sum(w in ES_WORDS for w in ws)
    if re.search(r"[áéíóúñ¿¡]", line.lower()):
        es += 1
    return en - es  # >0 inglés, <0 español


def split_pages(lines):
    pages, cur, num = [], [], None
    for ln in lines:
        m = PAGE_RE.match(ln.strip())
        if m:
            if cur:
                pages.append((num, cur))
            num, cur = int(m.group(1)), []
            continue
        if ln.strip():
            cur.append(ln.rstrip("\r\n"))
    if cur:
        pages.append((num, cur))
    return pages


def split_languages(page_lines):
    """Índice k tal que [:k] es inglés y [k:] español.

    En el texto extraído, las líneas en inglés que continúan en la siguiente terminan con un
    espacio y las españolas nunca: la última línea con espacio final (o con número de apartado)
    marca el final del bloque inglés; después se amplía con las líneas claramente inglesas.
    """
    n = len(page_lines)
    last = -1
    for i, l in enumerate(page_lines):
        s = l.strip()
        if l.endswith(" ") or CLAUSE_RE.match(s) or ARTICLE_RE.match(s) or ANNEX_RE.match(s):
            last = i
    if last < 0:
        k = 0
    else:
        k = last + 1
        if page_lines[last].endswith(" ") and k < n:
            k += 1  # la línea que cierra el párrafo envuelto también es inglés
    while k < n and lang_score(page_lines[k]) >= 2:
        k += 1
    return page_lines[:k], page_lines[k:]


def main(src, regs_path, dst):
    lines = open(src, encoding="utf-8").read().splitlines()
    regs = json.load(open(regs_path, encoding="utf-8"))
    nodes = regs["nodes"]

    # Títulos oficiales en español desde el índice (secciones, artículos y anexos)
    toc_es = {}
    sec = None
    for ln in lines[:260]:
        m = TOC_ES_RE.match(ln.strip())
        if not m:
            continue
        if m.group(2):
            sec = m.group(2)
            toc_es[sec] = m.group(5)
        elif m.group(3) and sec:
            toc_es[f"{sec}.{m.group(3)}"] = m.group(5)
        elif m.group(4):
            toc_es[f"Annex {m.group(4)}"] = m.group(5)

    # Ids repetidos: el parser renombra uno de ellos; aquí se asignan por orden de aparición
    occ_map = defaultdict(list)
    for n in nodes:
        base = n["id"].replace(" (2)", "")
        occ_map[base].append(n["id"])
    # orden real de aparición en el documento = orden de los nodos
    seen_count = defaultdict(int)

    def resolve(cid):
        lst = occ_map.get(cid)
        if not lst:
            return None
        i = seen_count[cid]
        seen_count[cid] += 1
        return lst[min(i, len(lst) - 1)]

    known = {n["id"] for n in nodes}
    pages = split_pages(lines)
    body_start = next(i for i, (_, pl) in enumerate(pages) if any(SECTION_RE.match(l.strip()) for l in pl))

    es_parts = defaultdict(list)
    stats = []
    section = None
    article = None
    current = None  # id del apartado que continúa en la página siguiente

    for num, pl in pages[body_start:]:
        en, es = split_languages(pl)
        # --- unidades en inglés
        units = []  # [id, kind, text]
        for l in en:
            s = l.strip()
            m = SECTION_RE.match(s)
            if m:
                section = m.group(1)
                current = None
                continue
            if s.startswith("SECTION ") or (units == [] and current is None and s.isupper() and not ARTICLE_RE.match(s)):
                continue
            m = ARTICLE_RE.match(s)
            if m and section:
                article = int(m.group(1))
                current = f"{section}.{article}"
                units.append([current, "title", m.group(2)])
                continue
            m = ANNEX_RE.match(s)
            if m:
                current = f"Annex {m.group(1)}"
                units.append([current, "annex", ""])
                continue
            m = CLAUSE_RE.match(s)
            if m:  # la cabecera "SECTION X" a veces cae en la columna española: manda el id
                cid = f"{m.group(1)}.{m.group(2)}{m.group(3)}"
                rid = resolve(cid) if cid in occ_map else None
                if rid:
                    section = m.group(1)
                    current = rid
                    depth = cid.count(".")
                    units.append([rid, "title" if depth == 2 else "text", m.group(4)])
                    continue
            if current is None:
                continue
            if units and units[-1][0] == current and units[-1][1] in ("text", "annex"):
                units[-1][2] += " " + s
            else:
                units.append([current, "text", s])  # continuación o texto bajo un título
        es_lines = [l.strip() for l in es if l.strip()]
        # Quitar cabeceras de sección/artículo en español: se alinean aparte por el índice
        es_lines = [l for l in es_lines if not re.match(r"^(SECCIÓN [A-J]|ARTÍCULO \d+:|ANEXO \d+:)", l)]
        es_lines = [l for l in es_lines if not (l.isupper() and len(l) < 80 and not re.search(r"[.:]$", l))]
        es_lines = [l for l in es_lines if not re.match(r"^Picture \d+", l)]  # pies de imagen en inglés
        units = [u for u in units if not (u[1] == "title" and u[0].count(".") == 1)]  # títulos de artículo: por índice
        if not units or not es_lines:
            continue
        seg = align(units, es_lines)
        for (uid, kind, en_text), (a, b) in zip(units, seg):
            txt = es_lines[a:b]
            if not txt:
                continue
            es_parts[uid].append((kind, txt))
            stats.append((uid, len(en_text), sum(len(t) for t in txt)))

    # --- construir salida
    out = {}
    for n in nodes:
        nid = n["id"]
        entry = {}
        if n["kind"] in ("article", "annex", "section"):
            t = toc_es.get(nid)
            if t:
                entry["title"] = t
        parts = es_parts.get(nid, [])
        title_lines = [t for k, t in parts if k == "title"]
        text_lines = [line for k, t in parts if k != "title" for line in t]
        if n["kind"] == "subsection" and title_lines:
            entry["title"] = " ".join(title_lines[0])
        if text_lines and n.get("text"):
            entry["text"] = join_lines(text_lines)
        if entry:
            out[nid] = entry

    # --- control de calidad: proporción de longitudes por apartado
    ratios = []
    for n in nodes:
        e = out.get(n["id"], {})
        if n.get("text") and e.get("text"):
            ratios.append((len(e["text"]) / max(1, len(n["text"])), n["id"]))
    ratios.sort()
    ok = [r for r, _ in ratios if 0.8 <= r <= 1.7]
    with_text = sum(1 for n in nodes if n.get("text"))
    print(f"apartados con texto: {with_text}, con español: {len(ratios)}, proporción razonable: {len(ok)}")
    print("proporción mediana:", round(ratios[len(ratios) // 2][0], 3))
    print("más cortos:", [(round(r, 2), i) for r, i in ratios[:8]])
    print("más largos:", [(round(r, 2), i) for r, i in ratios[-8:]])
    # Marcar como dudosos los que se salen mucho de la proporción: la web mostrará el inglés
    for r, i in ratios:
        if not (0.6 <= r <= 2.2):
            out[i]["doubtful"] = True
    json.dump({"revision": regs["revision"], "sections": {k: v for k, v in toc_es.items() if len(k) == 1}, "nodes": out},
              open(dst, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print("->", dst, len(out), "entradas")


def join_lines(lines):
    text = ""
    for l in lines:
        if not text:
            text = l
        elif l.startswith("- ") and text.count("(") > text.count(")"):
            text += " " + l
        elif l.startswith("- ") or l.startswith("• ") or re.match(r"^[a-z]\)\s", l) or text.endswith(":"):
            text += "\n" + l
        elif text.endswith(".") and l[:1].isupper() and len(prev_line(text)) < 70:
            text += "\n" + l  # línea anterior corta y acabada en punto: nuevo párrafo
        else:
            text += " " + l
    return re.sub(r"[ \t]{2,}", " ", text).strip()


def prev_line(text):
    return text.rsplit("\n", 1)[-1][-90:] if "\n" in text else text[-90:]


RATIO = 1.12  # longitud esperada español / inglés (se recalibra abajo)


def align(units, es):
    """Reparte las líneas en español entre las unidades (contiguas, en orden)."""
    U, L = len(units), len(es)
    en_len = [max(8, len(u[2])) for u in units]
    total_en = sum(en_len)
    total_es = sum(len(l) for l in es)
    ratio = max(0.7, min(1.6, total_es / max(1, total_en)))  # proporción de la propia página
    lens = [len(l) for l in es]
    pre = [0]
    for x in lens:
        pre.append(pre[-1] + x)

    def is_heading(l):
        return len(l) < 70 and not re.search(r"[.:;,]$", l) and l[:1].isupper()

    def boundary_cost(j):
        if j == 0:
            return 0.0
        prev, cur = es[j - 1], es[j]
        c = 0.0
        if re.search(r"[.:;!?)]$", prev) or is_heading(prev) or is_heading(cur):
            c -= 0.5
        else:
            c += 3.0
        if cur[:1].islower():
            c += 2.0
        return c

    INF = float("inf")
    dp = [[INF] * (L + 1) for _ in range(U + 1)]
    bk = [[0] * (L + 1) for _ in range(U + 1)]
    dp[0][0] = 0.0
    for i in range(1, U + 1):
        kind = units[i - 1][1]
        exp = en_len[i - 1] * ratio
        for j in range(0, L + 1):
            best, arg = INF, j
            # 0 líneas (unidad sin traducción): penalización
            if dp[i - 1][j] < INF:
                best, arg = dp[i - 1][j] + 6.0, j
            lo = max(0, j - 40)
            for a in range(j - 1, lo - 1, -1):
                if dp[i - 1][a] == INF:
                    continue
                seg_len = pre[j] - pre[a]
                c = dp[i - 1][a]
                c += 4.0 * (math.log((seg_len + 5) / (exp + 5))) ** 2
                c += boundary_cost(a)
                if kind == "title":
                    c += 0.0 if (j - a == 1 and is_heading(es[a])) else 3.0
                if c < best:
                    best, arg = c, a
            dp[i][j] = best
            bk[i][j] = arg
    # reconstruir
    seg = []
    j = L
    for i in range(U, 0, -1):
        a = bk[i][j]
        seg.append((a, j))
        j = a
    seg.reverse()
    return seg


if __name__ == "__main__":
    main(*sys.argv[1:4])
