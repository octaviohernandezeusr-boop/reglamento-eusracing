// Servidor del chat del reglamento MotoStudent — eUSRacing
// Arranque: `npm install` y `npm start` (ver README.md)
import "dotenv/config";
import express from "express";
import Anthropic from "@anthropic-ai/sdk";
import { fileURLToPath } from "node:url";
import { dirname, join, resolve } from "node:path";
import { timingSafeEqual } from "node:crypto";
import { loadRegulations, EFUEL_ONLY_IDS } from "./lib/regulations.js";
import { buildSystem } from "./lib/prompt.js";
import { mockStream } from "./lib/mock.js";
import { createStore } from "./lib/store.js";
import { createAuth } from "./lib/auth.js";
import { createOpenAIEngine, friendlyLLMError, PRESETS } from "./lib/llm.js";

const __dirname = dirname(fileURLToPath(import.meta.url));
const list = (v) => String(v || "").split(",").map((s) => s.trim().toLowerCase()).filter(Boolean);

// ---------- Configuración (variables de entorno / .env) ----------
const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || "127.0.0.1";
// Proveedor de IA: mistral (gratis, por defecto) | cerebras | groq | openrouter | gemini | ollama | custom | anthropic
const LLM_PROVIDER = (process.env.LLM_PROVIDER || "mistral").toLowerCase();
const MODEL = process.env.MODEL || "claude-sonnet-5"; // solo para LLM_PROVIDER=anthropic
const MAX_TOKENS = Number(process.env.MAX_TOKENS || 4000);
const THINKING = (process.env.THINKING || "adaptive").toLowerCase(); // adaptive | off
const EFFORT = process.env.EFFORT || ""; // low | medium | high (vacío = por defecto del modelo)
const CACHE_TTL = process.env.CACHE_TTL === "1h" ? "1h" : "5m";
const ACCESS_CODE = process.env.ACCESS_CODE || ""; // alternativa sencilla al login
const RATE_LIMIT_PER_HOUR = Number(process.env.RATE_LIMIT_PER_HOUR || 60);
const PRESET = PRESETS[LLM_PROVIDER];
const LLM_API_KEY = process.env.LLM_API_KEY || (PRESET?.keyEnv ? process.env[PRESET.keyEnv] : "") || "";
const USE_ANTHROPIC = LLM_PROVIDER === "anthropic";
if (!USE_ANTHROPIC && !PRESET) {
  console.error(`\n  ERROR: LLM_PROVIDER="${LLM_PROVIDER}" no existe. Usa: ${Object.keys(PRESETS).join(", ")} o anthropic.\n`);
  process.exit(1);
}
const MOCK = process.env.MOCK === "1" ||
  (USE_ANTHROPIC ? !process.env.ANTHROPIC_API_KEY : !LLM_API_KEY && !["ollama", "custom"].includes(LLM_PROVIDER));
const TRUST_PROXY = process.env.TRUST_PROXY === "1";
const DATA_DIR = resolve(process.env.DATA_DIR || join(__dirname, "storage"));
const DATABASE_URL = process.env.DATABASE_URL || ""; // Postgres (Neon, Supabase…) para alojamientos sin disco

// Login
const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID || "";
const APPLE_CLIENT_ID = process.env.APPLE_CLIENT_ID || ""; // Services ID, p. ej. com.eusracing.reglamento
const APPLE_REDIRECT_URI = process.env.APPLE_REDIRECT_URI || "";
const AUTH_ENABLED = Boolean(GOOGLE_CLIENT_ID || APPLE_CLIENT_ID);
const ALLOWED_EMAILS = list(process.env.ALLOWED_EMAILS);
const ALLOWED_DOMAINS = list(process.env.ALLOWED_DOMAINS);

const MAX_TURNS = 12; // mensajes de historial que se envían (los más recientes)
const MAX_MESSAGE_CHARS = 4000;

// El equipo compite en Electric: la Sección C y los apartados exclusivos de eFuel se excluyen
// de la IA y de la web. Pon EXCLUDE_SECTIONS= (vacío) en .env para incluir todo.
const EXCLUDE_SECTIONS = (process.env.EXCLUDE_SECTIONS ?? "C").split(",").map((s) => s.trim()).filter(Boolean);
const regs = loadRegulations(join(__dirname, "data", "regulations.json"), {
  exclude: EXCLUDE_SECTIONS,
  excludeIds: EXCLUDE_SECTIONS.includes("C") ? EFUEL_ONLY_IDS : [],
  esPath: join(__dirname, "data", "regulations.es.json"),
});
const systems = {
  en: buildSystem({ context: regs.context.en, revision: regs.doc.revision, cacheTtl: CACHE_TTL, lang: "en" }),
  es: buildSystem({ context: regs.context.es, revision: regs.doc.revision, cacheTtl: CACHE_TTL, lang: "es" }),
};
let thinkingOn = THINKING === "adaptive"; // se desactiva solo si el modelo no lo admite
const client = MOCK || !USE_ANTHROPIC ? null : new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
const engine = MOCK || USE_ANTHROPIC ? null : createOpenAIEngine({
  provider: LLM_PROVIDER,
  baseURL: process.env.LLM_BASE_URL,
  apiKey: LLM_API_KEY,
  model: process.env.LLM_MODEL,
  budget: process.env.LLM_CONTEXT_CHARS,
  scanChars: process.env.LLM_SCAN_CHARS,
  parallel: process.env.LLM_PARALLEL,
  rigor: (process.env.RIGOR || "max").toLowerCase(), // max | alto | rapido
  regs,
});
const ENGINE_LABEL = USE_ANTHROPIC ? `Claude (${MODEL})` : engine ? `${engine.label} · ${engine.model} · rigor ${engine.rigor}${engine.rigor === "max" ? ` (lee el reglamento completo en ${engine.blocks} bloques)` : ""}` : "modo demo";

let store;
try {
  store = await createStore({ dir: DATA_DIR, databaseUrl: DATABASE_URL });
} catch (e) {
  console.error(`\n  ERROR: no se pudo conectar con la base de datos (DATABASE_URL): ${e.message}\n`);
  process.exit(1);
}
let auth = null;
if (AUTH_ENABLED) {
  try {
    auth = createAuth({
      secret: process.env.SESSION_SECRET,
      googleClientId: GOOGLE_CLIENT_ID,
      appleClientId: APPLE_CLIENT_ID,
      allowedEmails: ALLOWED_EMAILS,
      allowedDomains: ALLOWED_DOMAINS,
      // Solo para las pruebas automáticas (test/auth-e2e.test.mjs): no lo definas en producción
      jwksUrls: process.env.NODE_ENV === "test" ? { google: process.env.TEST_JWKS_URL, apple: process.env.TEST_JWKS_URL } : {},
    });
  } catch (e) {
    console.error(`\n  ERROR: ${e.message}. Genera uno con:  node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"\n`);
    process.exit(1);
  }
}

const app = express();
if (TRUST_PROXY) app.set("trust proxy", 1); // detrás de nginx/Caddy/Cloudflare
app.disable("x-powered-by");
app.use(express.json({ limit: "600kb" }));
app.use((req, res, next) => {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
  // Necesario para la ventana emergente de Google / Apple
  res.setHeader("Cross-Origin-Opener-Policy", "same-origin-allow-popups");
  next();
});
app.use(express.static(join(__dirname, "public"), { extensions: ["html"] }));

// ---------- Quién es el usuario ----------
// - Con login (Google/Apple): la sesión de la cookie.
// - Con ACCESS_CODE y sin login: acceso con código; las conversaciones se guardan en el navegador.
// - Sin nada (uso local): un único usuario "local" con sus conversaciones en el servidor.
function checkCode(req) {
  const given = Buffer.from(String(req.get("x-access-code") || ""));
  const want = Buffer.from(ACCESS_CODE);
  return given.length === want.length && timingSafeEqual(given, want);
}
async function currentUser(req) {
  if (AUTH_ENABLED) {
    const uid = auth.sessionUserId(req);
    return uid ? store.getUser(uid) : null;
  }
  if (ACCESS_CODE) return checkCode(req) ? { id: "shared", name: "Equipo", shared: true } : null;
  return store.getUser("local");
}
async function requireUser(req, res, next) {
  try {
    const user = await currentUser(req);
    if (!user) return res.status(401).json({ error: AUTH_ENABLED ? "Inicia sesión para continuar." : "Código de acceso incorrecto" });
    req.user = user;
    next();
  } catch (e) {
    console.error("[auth]", e);
    res.status(500).json({ error: "Error interno del servidor" });
  }
}
function requireLibrary(req, res, next) {
  if (req.user.shared) return res.status(400).json({ error: "Con código de acceso las conversaciones se guardan en el navegador." });
  next();
}
const wrap = (fn) => (req, res) =>
  Promise.resolve(fn(req, res)).catch((e) => {
    if (!e.status || e.status >= 500) console.error("[api]", e);
    res.status(e.status || 500).json({ error: e.status ? e.message : "Error interno del servidor" });
  });

const hits = new Map(); // usuario o ip -> [timestamps]
function rateLimited(key) {
  const now = Date.now();
  const arr = (hits.get(key) || []).filter((t) => now - t < 3600_000);
  if (arr.length >= RATE_LIMIT_PER_HOUR) {
    hits.set(key, arr);
    return true;
  }
  arr.push(now);
  hits.set(key, arr);
  return false;
}
setInterval(() => {
  const now = Date.now();
  for (const [k, arr] of hits) if (!arr.some((t) => now - t < 3600_000)) hits.delete(k);
}, 600_000).unref();

// ---------- Configuración pública y sesión ----------
app.get("/api/config", (req, res) => {
  res.json({
    mock: MOCK,
    engine: USE_ANTHROPIC ? "Claude" : engine ? engine.short : null,
    revision: regs.doc.revision,
    title: regs.doc.title,
    auth: AUTH_ENABLED
      ? { mode: "oauth", google: GOOGLE_CLIENT_ID || null, apple: APPLE_CLIENT_ID ? { clientId: APPLE_CLIENT_ID, redirectURI: APPLE_REDIRECT_URI } : null }
      : ACCESS_CODE
        ? { mode: "code" }
        : { mode: "none" },
    library: AUTH_ENABLED || !ACCESS_CODE ? "server" : "browser",
  });
});

app.get("/api/me", wrap(async (req, res) => res.json({ user: await currentUser(req) })));
app.post("/api/check-code", (req, res) => res.json({ ok: !ACCESS_CODE || checkCode(req) }));

if (AUTH_ENABLED) {
  app.get("/auth/nonce", (req, res) => {
    res.setHeader("Cache-Control", "no-store");
    res.json({ nonce: auth.issueNonce(req, res) });
  });
  // Antes que /auth/:provider, que si no la capturaría
  app.post("/auth/logout", (req, res) => {
    auth.endSession(req, res);
    res.json({ ok: true });
  });
  app.post(
    "/auth/:provider",
    wrap(async (req, res) => {
      const provider = req.params.provider;
      if (provider !== "google" && provider !== "apple") return res.status(404).json({ error: "Proveedor desconocido" });
      const nonce = auth.takeNonce(req, res);
      const identity = await auth.verify(provider, req.body?.idToken, nonce);
      // Apple solo envía el nombre la primera vez, fuera del token
      if (provider === "apple" && !identity.name && req.body?.user?.name) {
        const n = req.body.user.name;
        identity.name = [n.firstName, n.lastName].filter(Boolean).join(" ").slice(0, 80);
      }
      const user = await store.findOrCreateUser(identity);
      auth.startSession(req, res, user.id);
      console.log(`[auth] ${provider} ${user.email || user.id}`);
      res.json({ user });
    })
  );
}

// ---------- Reglamento ----------
app.get("/api/regulations", requireUser, (req, res) => {
  res.setHeader("Cache-Control", "private, max-age=3600");
  res.json({ revision: regs.doc.revision, sections: regs.doc.sections, sectionsEs: regs.doc.sectionsEs, nodes: regs.doc.nodes });
});

// ---------- Conversaciones y carpetas ----------
const lib = express.Router();
lib.use(requireUser, requireLibrary);
lib.get("/library", wrap(async (req, res) => res.json(await store.library(req.user.id))));
lib.get("/conversations/:id", wrap(async (req, res) => {
  const c = await store.getConversation(req.user.id, req.params.id);
  return c ? res.json(c) : res.status(404).json({ error: "Conversación no encontrada" });
}));
lib.put("/conversations/:id", wrap(async (req, res) => {
  if (!/^[A-Za-z0-9_-]{6,64}$/.test(req.params.id)) return res.status(400).json({ error: "Id no válido" });
  res.json(await store.saveConversation(req.user.id, req.params.id, req.body || {}));
}));
lib.delete("/conversations/:id", wrap(async (req, res) => res.json(await store.deleteConversation(req.user.id, req.params.id))));
lib.post("/folders", wrap(async (req, res) => res.json(await store.createFolder(req.user.id, req.body?.name))));
lib.patch("/folders/:id", wrap(async (req, res) => res.json(await store.renameFolder(req.user.id, req.params.id, req.body?.name))));
lib.delete("/folders/:id", wrap(async (req, res) => res.json(await store.deleteFolder(req.user.id, req.params.id))));
app.use("/api", lib);

// ---------- Chat ----------
function sanitizeMessages(raw) {
  if (!Array.isArray(raw)) return null;
  const msgs = raw
    .filter((m) => m && (m.role === "user" || m.role === "assistant") && typeof m.content === "string")
    .map((m) => ({ role: m.role, content: m.content.slice(0, m.role === "user" ? MAX_MESSAGE_CHARS : 12000).trim() }))
    .filter((m) => m.content);
  // Recortar historial y asegurar que empieza y termina por el usuario
  let recent = msgs.slice(-MAX_TURNS);
  while (recent.length && recent[0].role !== "user") recent.shift();
  if (!recent.length || recent[recent.length - 1].role !== "user") return null;
  // Fusionar turnos consecutivos del mismo rol (la API exige alternancia)
  const merged = [];
  for (const m of recent) {
    const last = merged[merged.length - 1];
    if (last && last.role === m.role) last.content += "\n\n" + m.content;
    else merged.push({ ...m });
  }
  return merged;
}

app.post("/api/chat", requireUser, async (req, res) => {
  if (rateLimited(req.user.shared ? `ip:${req.ip}` : req.user.id)) {
    return res.status(429).json({ error: `Has llegado al límite de ${RATE_LIMIT_PER_HOUR} preguntas por hora. Prueba más tarde.` });
  }
  const messages = sanitizeMessages(req.body?.messages);
  if (!messages) return res.status(400).json({ error: "Conversación no válida" });
  const lang = req.body?.lang === "en" ? "en" : "es";
  const question = messages[messages.length - 1].content;

  res.writeHead(200, {
    "Content-Type": "text/event-stream; charset=utf-8",
    "Cache-Control": "no-cache, no-transform",
    Connection: "keep-alive",
    "X-Accel-Buffering": "no", // nginx: no bufferizar el streaming
  });
  const send = (event, data) => res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);

  const ac = new AbortController();
  res.on("close", () => ac.abort()); // el usuario pulsó "Parar" o cerró la pestaña

  try {
    if (MOCK) {
      await mockStream({ question, byId: regs.byId, send, signal: ac.signal, lang });
      send("done", { usage: null, mock: true });
      return res.end();
    }
    if (engine) {
      await engine.answer({ messages, lang, send, signal: ac.signal });
      send("done", {});
    } else {
      const usage = await streamAnswer(messages, send, ac.signal, thinkingOn, lang);
      send("done", { usage });
    }
  } catch (err) {
    if (ac.signal.aborted) return res.end();
    console.error("[chat] error:", err?.status || "", err?.message || err);
    send("error", { error: engine ? friendlyLLMError(err, engine) : friendlyError(err) });
  }
  res.end();
});

async function streamAnswer(messages, send, signal, useThinking, lang) {
  const params = { model: MODEL, max_tokens: MAX_TOKENS, system: systems[lang], messages };
  if (useThinking) params.thinking = { type: "adaptive", display: "omitted" };
  if (useThinking && EFFORT) params.output_config = { effort: EFFORT };

  let started = false;
  try {
    const stream = client.messages.stream(params, { signal });
    stream.on("streamEvent", (ev) => {
      if (ev.type === "content_block_start" && ev.content_block?.type === "thinking") send("status", { status: "thinking" });
    });
    stream.on("text", (delta) => {
      started = true;
      send("text", { delta });
    });
    const final = await stream.finalMessage();
    if (final.stop_reason === "max_tokens") send("status", { status: "truncated" });
    const u = final.usage || {};
    console.log(
      `[chat] ${MODEL} ${lang} in=${u.input_tokens} cache_read=${u.cache_read_input_tokens || 0} cache_write=${u.cache_creation_input_tokens || 0} out=${u.output_tokens}`
    );
    return { input: u.input_tokens, cacheRead: u.cache_read_input_tokens || 0, cacheWrite: u.cache_creation_input_tokens || 0, output: u.output_tokens };
  } catch (err) {
    // Si el modelo elegido no admite "adaptive thinking", se reintenta sin él una vez.
    if (useThinking && !started && err?.status === 400 && /thinking|effort|output_config/i.test(err?.message || "")) {
      console.warn("[chat] el modelo no acepta thinking/effort; se desactivan a partir de ahora");
      thinkingOn = false;
      return streamAnswer(messages, send, signal, false, lang);
    }
    throw err;
  }
}

function friendlyError(err) {
  const s = err?.status;
  if (s === 401) return "La API key de Anthropic no es válida. Revisa el archivo .env del servidor.";
  if (s === 404) return `El modelo "${MODEL}" no existe o no está disponible para esta API key. Cambia MODEL en .env.`;
  if (s === 429) return "La API de Anthropic está limitando las peticiones. Espera un momento y vuelve a intentarlo.";
  if (s === 529 || s === 503) return "Los servidores de Anthropic están saturados. Inténtalo de nuevo en unos segundos.";
  if (s === 400 && /credit|billing/i.test(err?.message || "")) return "La cuenta de la API no tiene saldo. Revisa la facturación en console.anthropic.com.";
  return "No se pudo obtener respuesta. Inténtalo de nuevo.";
}

app.listen(PORT, HOST, () => {
  const k = (s) => Math.round(s.length / 4000);
  console.log(`\n  Chat del reglamento MotoStudent — eUSRacing`);
  console.log(`  → http://${HOST === "0.0.0.0" ? "localhost" : HOST}:${PORT}`);
  console.log(`  IA: ${ENGINE_LABEL}${MOCK ? `  (MODO DEMO: falta la clave${PRESET?.keyEnv ? ` ${PRESET.keyEnv}` : ""}; respuestas simuladas)` : ""}`);
  console.log(`  Reglamento: ${regs.doc.nodes.length} apartados · contexto ~${k(regs.context.es)}k tokens (ES) / ~${k(regs.context.en)}k (EN)`);
  if (AUTH_ENABLED) {
    console.log(`  Login: ${[GOOGLE_CLIENT_ID && "Google", APPLE_CLIENT_ID && "Apple"].filter(Boolean).join(" + ")}`);
    if (!ALLOWED_EMAILS.length && !ALLOWED_DOMAINS.length) console.log("  AVISO: cualquier cuenta puede entrar. Limítalo con ALLOWED_EMAILS o ALLOWED_DOMAINS.");
  } else if (ACCESS_CODE) console.log("  Acceso con código (ACCESS_CODE); conversaciones en el navegador");
  else console.log("  Sin login (uso local)");
  console.log(`  Conversaciones: ${store.kind} (${store.where})`);
  console.log("");
});
